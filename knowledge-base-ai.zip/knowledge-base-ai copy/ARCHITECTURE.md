# AI-Powered Knowledge Base Search & Enrichment - System Architecture

## Overview
A RAG (Retrieval-Augmented Generation) system that enables semantic search across uploaded documents, generates AI-powered answers with completeness detection, and suggests knowledge base enrichment strategies.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         Frontend (React + Vite)                 │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────────────┐     │
│  │  Document    │  │   Search     │  │  Answer Display    │     │
│  │  Upload UI   │  │   Interface  │  │  + Enrichment UI   │     │
│  └──────────────┘  └──────────────┘  └────────────────────┘     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ HTTP/REST API
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Backend (FastAPI)                          │
│                                                                 │
│  ┌────────────────────────────────────────────────────────┐     │
│  │           API Endpoints Layer                          │     │
│  │  • POST /upload        • POST /search                  │     │
│  │  • GET /documents      • POST /rate-answer             │     │
│  │  • POST /enrich        • GET /health                   │     │
│  └────────────────────────────────────────────────────────┘     │
│                              │                                  │
│  ┌────────────────────────────────────────────────────────┐     │
│  │           Business Logic Layer                         │     │
│  │                                                        │     │
│  │  ┌──────────────────┐  ┌──────────────────────────┐    │     │
│  │  │  Document        │  │  RAG Pipeline            │    │     │
│  │  │  Processor       │  │  • Chunking              │    │     │
│  │  │  • PDF Parser    │  │  • Embedding             │    │     │
│  │  │  • DOCX Parser   │  │  • Retrieval             │    │     │
│  │  │  • TXT Parser    │  │  • Generation            │    │     │
│  │  └──────────────────┘  └──────────────────────────┘    │     │
│  │                                                        │     │
│  │  ┌──────────────────┐  ┌──────────────────────────┐    │     │
│  │  │  Completeness    │  │  Enrichment Engine       │    │     │
│  │  │  Detector        │  │  • Gap Analysis          │    │     │
│  │  │  • Confidence    │  │  • Suggestions           │    │     │
│  │  │  • Missing Info  │  │  • Auto-Enrichment       │    │     │
│  │  └──────────────────┘  └──────────────────────────┘    │     │
│  └────────────────────────────────────────────────────────┘     │
│                              │                                  │
└──────────────────────────────┼──────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────────┐
│   ChromaDB   │    │   OpenAI     │    │  File Storage    │
│   (Vectors)  │    │   API        │    │  (Documents)     │
│              │    │  • GPT-4     │    │  • Local FS      │
│  • Chunks    │    │  • Embeddings│    │  • Metadata DB   │
│  • Embeddings│    │              │    │    (SQLite)      │
│  • Metadata  │    │              │    │                  │
└──────────────┘    └──────────────┘    └──────────────────┘
```

## Component Breakdown

### 1. Frontend Layer (React + Vite)
**Technology**: React 18, TypeScript, Vite, TailwindCSS, shadcn/ui

**Components**:
- **Document Upload**: Drag-and-drop interface for PDF/DOCX/TXT files
- **Search Interface**: Natural language query input with real-time suggestions
- **Answer Display**: Shows AI-generated answer with:
  - Confidence score (visual indicator)
  - Source citations (clickable references)
  - Missing information highlights
  - Enrichment suggestions panel
- **Rating System**: Thumbs up/down for answer quality

### 2. Backend Layer (FastAPI)

#### API Endpoints

```python
# Document Management
POST /api/v1/upload          # Upload documents
GET  /api/v1/documents       # List uploaded documents
DELETE /api/v1/documents/{id} # Remove document

# Search & Query
POST /api/v1/search          # Natural language search
POST /api/v1/enrich          # Auto-enrich knowledge base

# Feedback
POST /api/v1/rate-answer     # Rate answer quality

# System
GET  /api/v1/health          # Health check
GET  /api/v1/stats           # Knowledge base statistics
```

#### Core Services

**a) Document Processing Service**
- Accepts: PDF, DOCX, TXT, MD
- Extracts text with metadata preservation
- Performs intelligent chunking:
  - Semantic chunking (paragraph-aware)
  - Overlap between chunks (200 tokens)
  - Maximum chunk size: 512 tokens
  
**b) Embedding Service**
- Model: `text-embedding-3-small` (OpenAI)
- Dimension: 1536
- Batch processing for efficiency
- Caching for repeated queries

**c) Retrieval Service**
- Vector similarity search (ChromaDB)
- Hybrid search: Vector + Keyword (BM25)
- Re-ranking with cross-encoder
- Top-k retrieval (k=5 default)

**d) Generation Service**
- Model: GPT-4-turbo
- Structured output (JSON mode)
- Prompt engineering for:
  - Answer generation
  - Confidence scoring
  - Missing info detection
  - Enrichment suggestions

**e) Completeness Detector**
- Analyzes answer quality
- Confidence scoring algorithm:
  ```
  confidence = (
    source_relevance * 0.4 +
    answer_completeness * 0.3 +
    source_coverage * 0.2 +
    query_answer_alignment * 0.1
  )
  ```
- Identifies missing information patterns
- Categorizes gaps (temporal, factual, contextual)

**f) Enrichment Engine**
- **Gap Analysis**: Identifies knowledge gaps
- **Suggestion Generator**: Proposes improvements
  - Missing document types
  - Additional data sources
  - Specific topics to cover
- **Auto-Enrichment** (Stretch Goal):
  - Wikipedia API integration
  - Web scraping (with permissions)
  - External API integration

### 3. Data Layer

#### ChromaDB (Vector Store)
```python
Collection Schema:
{
  "ids": ["chunk_1", "chunk_2", ...],
  "embeddings": [[...], [...], ...],
  "documents": ["text chunk 1", "text chunk 2", ...],
  "metadatas": [
    {
      "document_id": "doc_123",
      "filename": "report.pdf",
      "page": 5,
      "chunk_index": 2,
      "total_chunks": 10,
      "created_at": "2025-10-25T12:00:00Z"
    },
    ...
  ]
}
```

#### SQLite (Metadata Store)
```sql
Tables:
- documents (id, filename, file_type, size, upload_date, status)
- chunks (id, document_id, content, chunk_index, page_number)
- queries (id, query_text, timestamp, results_count)
- ratings (id, query_id, rating, feedback, timestamp)
- enrichment_logs (id, gap_type, suggestion, status, timestamp)
```

### 4. LLM Integration

#### Prompt Templates

**a) Answer Generation Prompt**
```
You are an AI assistant analyzing documents to answer questions.

Context from documents:
{retrieved_chunks}

User Question: {query}

Provide a comprehensive answer in the following JSON format:
{
  "answer": "Detailed answer based on the documents",
  "confidence": 0.0-1.0,
  "sources": ["doc_name:page_num", ...],
  "missing_info": ["What information is missing or uncertain"],
  "enrichment_suggestions": ["What documents/data would help complete the answer"]
}

Rules:
1. Only use information from the provided context
2. If information is incomplete, explicitly state it
3. Assign confidence based on evidence quality
4. Be specific about missing information
5. Provide actionable enrichment suggestions
```

**b) Completeness Detection Prompt**
```
Analyze this answer for completeness:

Question: {query}
Answer: {answer}
Available Context: {context}

Evaluate:
1. Does the answer fully address the question?
2. What information is missing or uncertain?
3. What additional documents would help?

Return JSON with detailed gap analysis.
```

### 5. 🆕 Hybrid AI System (OpenAI + Local Models)

#### Overview
The system implements intelligent fallback between cloud-based OpenAI and local models, ensuring the application always works regardless of API availability or quota constraints.

#### Architecture
```
Query/Document Processing
         │
         ▼
  ┌──────────────┐
  │ AI Orchestrator│
  └──────────────┘
         │
         ▼
   Try OpenAI First
         │
    ┌────┴────┐
    │         │
 Success   Failure
    │      (RateLimitError)
    │         │
    ▼         ▼
 Use Result  Switch to Local
             │
             ▼
         Local Models
         (Always Works)
```

#### Implementation Details

**Embedding Service (`embeddings.py`)**
```python
class EmbeddingService:
    def __init__(self):
        self.client = None  # OpenAI client
        self.use_local = settings.use_local_models
        self.local_service = None  # Lazy-loaded
        
    def generate_embedding(self, text: str) -> List[float]:
        try:
            if not self.use_local and self.client:
                # Try OpenAI first
                return self.client.embeddings.create(...)
        except openai.RateLimitError:
            logger.warning("OpenAI quota exceeded, switching to local")
            self.use_local = True
            
        # Fallback to local
        return self.local_service.generate_embedding(text)
```

**LLM Service (`llm_service.py`)**
```python
class LLMService:
    def generate_answer(self, query, chunks):
        try:
            if not self.use_local and self.client:
                # Try OpenAI GPT-4
                return self.client.chat.completions.create(...)
        except openai.RateLimitError:
            logger.warning("OpenAI quota exceeded, switching to local")
            self.use_local = True
            
        # Fallback to local LLM
        return self.local_service.generate_answer(query, chunks)
```

**Local Embeddings (`local_embeddings.py`)**
- **Model**: sentence-transformers/all-MiniLM-L6-v2
- **Dimensions**: 384 (vs OpenAI's 1536)
- **Speed**: ~50-100ms per embedding
- **Quality**: Good for general semantic similarity

**Local LLM (`local_llm.py`)**
- **Implementation**: Rule-based answer generation
- **Strategy**: Extractive summarization from retrieved chunks
- **Confidence**: Conservative scoring (typically 0.4-0.6)
- **Quality**: Adequate for demo, less nuanced than GPT-4

#### Configuration

**Environment Variables (`.env`)**
```bash
# OpenAI (Primary)
OPENAI_API_KEY=sk-...              # Or "demo-mode" for local-only

# Auto-fallback
USE_LOCAL_MODELS=False             # Auto-enabled on API failures

# Model Selection
EMBEDDING_MODEL=text-embedding-3-small
LOCAL_EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
LLM_MODEL=gpt-4-turbo-preview
```

#### Quality Comparison

| Aspect | OpenAI Mode | Local Mode |
|--------|-------------|------------|
| **Embedding Quality** | ⭐⭐⭐⭐⭐ (1536D) | ⭐⭐⭐⭐ (384D) |
| **Answer Quality** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| **Confidence Accuracy** | High (0.7-0.9) | Medium (0.4-0.6) |
| **Speed** | 2-4s | 2-3s |
| **Cost** | ~$0.05/query | $0 |
| **Offline Support** | ❌ | ✅ |
| **API Dependency** | ✅ | ❌ |

#### Benefits

1. **Demo-Ready**: Works immediately without API setup
2. **Cost-Effective**: Zero API costs for testing
3. **Resilient**: Never fails due to quota issues
4. **Production-Ready**: Auto-upgrades with API key
5. **Transparent**: Logs clearly show which mode is active

#### Limitations

1. **Local embeddings** have lower dimensionality (384 vs 1536)
2. **Local LLM** produces simpler, less nuanced answers
3. **Confidence scores** tend to be lower in local mode
4. **No true generative AI** in local LLM (rule-based only)

#### Future Enhancements

- Integrate Ollama for true local LLM (Llama 2/3, Mistral)
- Add model quality detection and automatic switching
- Cache OpenAI results to reduce API calls
- Support multiple embedding models

## Data Flow

### Document Upload Flow
```
1. User uploads document → Frontend
2. Frontend sends file → POST /api/v1/upload
3. Backend validates file (type, size)
4. Document parser extracts text + metadata
5. Text chunker creates semantic chunks
6. Embedding service generates vectors
7. ChromaDB stores chunks + embeddings
8. SQLite stores document metadata
9. Return success with document_id
```

### Search & Answer Flow
```
1. User enters query → Frontend
2. Frontend sends query → POST /api/v1/search
3. Backend generates query embedding
4. ChromaDB retrieves top-k similar chunks
5. Chunks are re-ranked for relevance
6. LLM generates answer with structured output:
   - Answer text
   - Confidence score
   - Missing information
   - Enrichment suggestions
7. Response formatted and cached
8. Return JSON to frontend
9. Frontend displays results with UI enhancements
```

### Auto-Enrichment Flow (Stretch Goal)
```
1. System detects low confidence answer
2. Enrichment engine analyzes gaps
3. External API calls (Wikipedia, web search)
4. New content processed and added
5. User notified of enrichment
6. Re-run query with enriched knowledge base
```

## Technology Stack

### Backend
- **Framework**: FastAPI 0.104+
- **Python**: 3.11+
- **Vector DB**: ChromaDB 0.4+
- **Database**: SQLite 3
- **Document Processing**: 
  - PyPDF2 (PDF)
  - python-docx (DOCX)
  - unstructured (advanced parsing)
- **🆕 Hybrid AI System**:
  - **Primary LLM**: OpenAI GPT-4-turbo-preview
  - **Fallback LLM**: Local rule-based system
  - **Primary Embeddings**: OpenAI text-embedding-3-small (1536D)
  - **Fallback Embeddings**: sentence-transformers/all-MiniLM-L6-v2 (384D)
  - **Auto-switching**: Detects API failures and switches seamlessly
  - **Zero-cost demo**: Works without OpenAI credits
- **LLM Integration**: 
  - OpenAI Python SDK
  - sentence-transformers (local embeddings)

### Frontend
- **Framework**: React 18
- **Build Tool**: Vite 5
- **Language**: TypeScript 5
- **Styling**: TailwindCSS 3
- **Components**: shadcn/ui
- **State Management**: Zustand
- **API Client**: Axios

### DevOps
- **Containerization**: Docker + Docker Compose
- **API Docs**: FastAPI auto-generated (Swagger/OpenAPI)
- **Logging**: structlog
- **Monitoring**: Built-in metrics endpoint

## Design Decisions

### 1. Why ChromaDB over Pinecone/Weaviate?
- **Local-first**: Easy setup, no external dependencies
- **Development speed**: Perfect for 24h constraint
- **Feature-complete**: Supports filtering, metadata, persistence
- **Trade-off**: Limited to single-machine scale (acceptable for prototype)

### 2. Why OpenAI over Open-Source Models?
- **Reliability**: Consistent quality and uptime
- **Speed**: No local GPU setup required
- **Structured Output**: Native JSON mode support
- **Trade-off**: API costs and vendor lock-in (mitigated with abstraction layer)

### 3. Chunking Strategy
- **Semantic Chunking**: Preserves meaning over fixed-size chunks
- **Overlap**: 200 tokens overlap prevents context loss
- **Trade-off**: More chunks = higher storage/retrieval cost, but better accuracy

### 4. Confidence Scoring Algorithm
- **Multi-factor**: Source relevance + completeness + coverage
- **Transparent**: Users see why confidence is low
- **Trade-off**: Heuristic-based (could use ML model in production)

### 5. SQLite for Metadata
- **Simplicity**: Single file database
- **ACID**: Reliable for document tracking
- **Trade-off**: Not ideal for multi-user concurrent writes (use PostgreSQL in production)

## Security Considerations

1. **File Upload Validation**
   - Type checking (magic numbers, not just extensions)
   - Size limits (50MB per file)
   - Virus scanning (optional, with ClamAV)

2. **API Rate Limiting**
   - Per-endpoint limits
   - IP-based throttling

3. **Data Privacy**
   - Documents stored locally
   - No data sent to third parties (except OpenAI)
   - Option to use local LLMs for sensitive data

4. **Input Sanitization**
   - Query validation
   - SQL injection prevention (ORM)
   - XSS protection (frontend)

## Performance Optimization

1. **Caching Strategy**
   - Query result caching (5 min TTL)
   - Embedding caching
   - LRU cache for frequent queries

2. **Async Processing**
   - FastAPI async endpoints
   - Background tasks for document processing
   - Batch embedding generation

3. **Lazy Loading**
   - Frontend pagination
   - Streaming responses for long answers
   - Progressive document loading

## Testing Strategy

1. **Unit Tests**: Core services (parsers, embeddings, retrieval)
2. **Integration Tests**: API endpoints with mock LLM
3. **E2E Tests**: Full workflow with sample documents
4. **Load Tests**: Concurrent users, large documents

## Deployment Plan

### Local Development
```bash
# Backend
cd backend && pip install -r requirements.txt
uvicorn app.main:app --reload

# Frontend
cd frontend && npm install && npm run dev
```

### Docker Deployment
```bash
docker-compose up
```

### Cloud Deployment (Optional)
- Backend: Railway / Render / Fly.io
- Frontend: Vercel / Netlify
- Database: Persistent volumes

## Success Metrics

1. **Functionality**: All core requirements met
2. **Accuracy**: >80% user rating for answers
3. **Performance**: <3s average query response time
4. **Usability**: Intuitive UI with clear feedback
5. **Documentation**: Comprehensive setup and usage guide

## Timeline (24 Hours)

| Hour | Task |
|------|------|
| 0-2  | Project setup + dependencies |
| 2-6  | Backend core (upload, processing, embeddings) |
| 6-10 | RAG pipeline (retrieval + generation) |
| 10-13 | Completeness detection + enrichment |
| 13-17 | Frontend development |
| 17-19 | Stretch goals (auto-enrichment, ratings) |
| 19-22 | Testing + bug fixes |
| 22-23 | Documentation |
| 23-24 | Demo video |

## Future Enhancements

1. Multi-modal support (images, tables, charts)
2. Conversational search (follow-up questions)
3. Knowledge graph visualization
4. Collaborative features (teams, sharing)
5. Custom embedding models
6. Multi-language support
7. Advanced analytics dashboard

