# Demo Video Script (5 Minutes Max)

## Pre-Recording Checklist

- [ ] Backend running on http://localhost:8000
- [ ] Frontend running on http://localhost:5173
- [ ] OpenAI API key configured (or use demo mode with local models) 🆕
- [ ] 2-3 sample documents ready (PDF, DOCX, or TXT)
- [ ] Screen recording software ready (Loom, OBS, QuickTime, etc.)
- [ ] Browser window sized appropriately
- [ ] Notifications disabled

## 🆕 Key Feature: Hybrid AI System

**Important:** This application now features a hybrid OpenAI + Local models system:
- Works **without** OpenAI API key (demo mode using local models)
- Automatically uses OpenAI when available for best quality
- Seamlessly falls back to local models if quota exceeded
- **Demo tip:** You can showcase this working even without API credits!

## Video Structure (5 minutes)

### Intro (30 seconds)

**What to say:**
> "Hi! I'm demonstrating my solution to Challenge 2: AI-Powered Knowledge Base Search & Enrichment. This system allows you to upload documents, search them using natural language, and get AI-generated answers with completeness detection and automatic enrichment suggestions. A unique feature is the hybrid AI system that seamlessly switches between OpenAI and local models, ensuring the application always works regardless of API availability."

**What to show:**
- Quick pan of the application interface
- Highlight the three main tabs: Upload, Search, Documents

### Part 1: Document Upload (1 minute)

**What to say:**
> "Let's start by uploading some documents. I'll drag and drop a few files here."

**What to do:**
1. Click on "Upload Documents" tab
2. Drag 2-3 documents (different formats: PDF, DOCX, TXT)
3. Show upload progress
4. Point out:
   - File validation
   - Real-time processing status
   - Number of chunks created

**What to say:**
> "The system automatically processes these documents - extracting text, chunking it semantically, generating embeddings, and storing them in a vector database. You can see this one created 15 chunks from 3,500 tokens."

### Part 2: High-Confidence Search (1 minute)

**What to say:**
> "Now let's search for something that's well-covered in our documents."

**What to do:**
1. Switch to "Search & Ask" tab
2. Type a query that should have good coverage (e.g., "What are the main conclusions?")
3. Click "Search Knowledge Base"
4. Wait for results
5. Highlight:
   - **AI-generated answer**
   - **High confidence score (>80%)**
   - **Source references** with relevance scores
   - **Quick response time**

**What to say:**
> "The system retrieved relevant chunks, sent them to GPT-4, and generated this comprehensive answer with an 85% confidence score. You can see it cites multiple sources with their relevance scores."

### Part 3: Low-Confidence Search & Completeness Detection (1.5 minutes)

**What to say:**
> "Now let's ask something that's not well-covered in our knowledge base."

**What to do:**
1. Enter a query with expected gaps (e.g., "What are the specific implementation timelines?" or "What were the budget allocations?")
2. Submit search
3. Point out:
   - **Lower confidence score** (e.g., 45%)
   - **Answer with explicit uncertainty statements**
   - **Orange/yellow warning badge**
   - **"Knowledge Gaps Detected" section**

**What to say:**
> "Notice the confidence is only 45% and the system has detected knowledge gaps. It explicitly tells us what information is missing."

4. Scroll to "Missing Information" section
5. Read out 1-2 examples of missing info

**What to say:**
> "The AI identified these specific gaps: temporal information about when things happened, and quantitative data about budget allocations."

### Part 4: Enrichment Suggestions (1 minute)

**What to do:**
1. Click "View Suggestions" button
2. Show enrichment analysis:
   - Different **gap types** (factual, temporal, quantitative)
   - **Priority levels** (high, medium, low)
   - **Suggested actions**

**What to say:**
> "The system categorizes gaps and provides actionable suggestions. It tells us to upload financial reports for the quantitative data, and historical documentation for timelines."

3. Click "Auto-Enrich" button
4. Wait for Wikipedia enrichment
5. Show results:
   - "Auto-enriched from Wikipedia" badge
   - New sources added
   - Links to Wikipedia articles

**What to say:**
> "I just clicked Auto-Enrich and the system automatically fetched relevant content from Wikipedia. Now we have three new sources to improve our knowledge base."

### Part 5: Additional Features (45 seconds)

**What to do:**
1. Show rating system - click thumbs up
2. Switch to "My Documents" tab
3. Show statistics:
   - Total documents
   - Total chunks
   - Average confidence
   - Query history

**What to say:**
> "Users can rate answers to help improve the system. The Documents tab shows comprehensive statistics and lets you manage your knowledge base."

4. Briefly show document list with metadata
5. Show delete functionality (hover over trash icon but don't delete)

### Outro (30 seconds)

**What to say:**
> "To summarize, this system provides:
> - Automatic document processing with semantic chunking
> - AI-powered search with confidence scoring
> - Completeness detection that identifies gaps
> - Smart enrichment suggestions with auto-enrichment from Wikipedia
> - User feedback to continuously improve
> 
> All of this was built in 24 hours using FastAPI, ChromaDB, OpenAI, and React. The code includes comprehensive documentation, Docker support, and production-ready patterns. Thank you!"

**What to show:**
- Quick pan back through all three tabs
- End on the home screen

---

## Recording Tips

### Technical Setup

1. **Resolution**: Record at 1920x1080 or 1280x720
2. **Frame Rate**: 30 fps minimum
3. **Audio**: Use good microphone, minimize background noise
4. **Browser**: Use Chrome/Edge for best performance
5. **Window Size**: Full screen or large window

### Content Tips

1. **Pace**: Speak clearly but keep moving - you have 5 minutes
2. **Preparation**: Practice once before recording
3. **Smooth Transitions**: Have documents pre-selected
4. **Error Handling**: If something goes wrong, pause and edit later
5. **Enthusiasm**: Show excitement about the features!

### Common Pitfalls to Avoid

- ❌ Don't spend too long on any one section
- ❌ Don't get stuck waiting for API responses (pre-warm if possible)
- ❌ Don't read text directly from screen - paraphrase
- ❌ Don't apologize for features or limitations
- ❌ Don't go into technical implementation details

### Sample Queries to Use

**High-Confidence Queries** (use documents about these topics):
- "What are the main conclusions?"
- "Summarize the key findings"
- "What is the executive summary?"
- "What are the recommendations?"

**Low-Confidence Queries** (intentionally not in your documents):
- "What are the specific budget allocations?"
- "What is the implementation timeline?"
- "What were the exact dates for each phase?"
- "How many people were involved?"

---

## Post-Recording

1. **Trim**: Cut any dead air or mistakes
2. **Add Captions**: Consider adding subtitles
3. **Check Length**: Ensure under 5 minutes
4. **Quality Check**: Watch once to verify audio/video quality
5. **Upload**: Use Loom, YouTube (unlisted), or Vimeo
6. **Add Link**: Update README.md with video link

---

## Alternative: Shorter Format (3 minutes)

If time is tight, focus on:

1. **Intro** (15s): Quick overview
2. **Upload** (30s): Show document processing
3. **Search** (45s): One search with good results
4. **Gaps** (45s): Low confidence + gap detection
5. **Enrichment** (30s): Auto-enrich demo
6. **Outro** (15s): Summary

---

## Backup Plan

If live demo has issues:

1. Record voice-over separately
2. Use pre-recorded footage
3. Add text overlays to explain features
4. Focus on what works, skip problematic parts

---

## Video Platforms

**Recommended:**
- **Loom** (easiest, 5-min free tier, good for tech demos)
- **YouTube** (unlisted link, no time limit)
- **Vimeo** (professional look)

**Recording Software:**
- Mac: QuickTime (built-in)
- Windows: OBS Studio (free), Xbox Game Bar (built-in)
- Cross-platform: OBS Studio, Loom browser extension

---

Good luck with your recording! 🎬

