import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api/v1'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Types
export interface Document {
  id: number
  filename: string
  file_type: string
  file_size: number
  upload_date: string
  status: string
  num_chunks: number
}

export interface SourceReference {
  document_id: number
  document_name: string
  page_number?: number
  chunk_text: string
  relevance_score: number
}

export interface SearchResponse {
  query: string
  answer: string
  confidence: number
  sources: SourceReference[]
  missing_info: string[]
  enrichment_suggestions: string[]
  query_id: number
  response_time: number
}

export interface EnrichmentSuggestion {
  gap_type: string
  description: string
  suggested_actions: string[]
  priority: string
}

export interface EnrichmentResponse {
  query: string
  suggestions: EnrichmentSuggestion[]
  auto_enriched: boolean
  new_sources: string[]
}

export interface Stats {
  total_documents: number
  total_chunks: number
  total_queries: number
  average_confidence: number
  average_response_time: number
  positive_ratings: number
  negative_ratings: number
  documents_by_type: Record<string, number>
}

// API Functions
export const uploadDocument = async (file: File): Promise<any> => {
  const formData = new FormData()
  formData.append('file', file)
  
  const response = await api.post('/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  })
  
  return response.data
}

export const getDocuments = async (): Promise<Document[]> => {
  const response = await api.get('/documents')
  return response.data
}

export const deleteDocument = async (id: number): Promise<void> => {
  await api.delete(`/documents/${id}`)
}

export const search = async (query: string, topK: number = 5): Promise<SearchResponse> => {
  const response = await api.post('/search', {
    query,
    top_k: topK,
  })
  return response.data
}

export const rateAnswer = async (
  queryId: number,
  rating: number,
  feedback?: string
): Promise<void> => {
  await api.post('/rate-answer', {
    query_id: queryId,
    rating,
    feedback,
  })
}

export const enrichKnowledgeBase = async (
  query: string,
  missingInfo: string[],
  autoEnrich: boolean = false
): Promise<EnrichmentResponse> => {
  const response = await api.post('/enrich', {
    query,
    missing_info: missingInfo,
    auto_enrich: autoEnrich,
  })
  return response.data
}

export const getStats = async (): Promise<Stats> => {
  const response = await api.get('/stats')
  return response.data
}

export const getHealth = async (): Promise<any> => {
  const response = await api.get('/health')
  return response.data
}

export default api

