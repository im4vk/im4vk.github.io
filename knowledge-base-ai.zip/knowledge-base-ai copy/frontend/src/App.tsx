import { useState } from 'react'
import DocumentUpload from './components/DocumentUpload'
import SearchInterface from './components/SearchInterface'
import DocumentList from './components/DocumentList'
import { FileText, Search, BarChart3 } from 'lucide-react'

type Tab = 'upload' | 'search' | 'documents'

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('upload')

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-primary-600 p-2 rounded-lg">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  AI Knowledge Base
                </h1>
                <p className="text-sm text-gray-600">
                  Search & Enrichment System
                </p>
              </div>
            </div>
            <div className="text-sm text-gray-500">
              v1.0.0
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('upload')}
              className={`
                flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm
                ${activeTab === 'upload'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }
              `}
            >
              <FileText className="w-5 h-5" />
              <span>Upload Documents</span>
            </button>
            
            <button
              onClick={() => setActiveTab('search')}
              className={`
                flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm
                ${activeTab === 'search'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }
              `}
            >
              <Search className="w-5 h-5" />
              <span>Search & Ask</span>
            </button>
            
            <button
              onClick={() => setActiveTab('documents')}
              className={`
                flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm
                ${activeTab === 'documents'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }
              `}
            >
              <FileText className="w-5 h-5" />
              <span>My Documents</span>
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'upload' && <DocumentUpload />}
        {activeTab === 'search' && <SearchInterface />}
        {activeTab === 'documents' && <DocumentList />}
      </main>

      {/* Footer */}
      <footer className="mt-auto py-6 text-center text-sm text-gray-500">
        <p>AI-Powered Knowledge Base with RAG Search & Enrichment</p>
      </footer>
    </div>
  )
}

export default App

