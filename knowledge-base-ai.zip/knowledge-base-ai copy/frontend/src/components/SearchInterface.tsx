import { useState } from 'react'
import { Search, Loader, AlertCircle, ThumbsUp, ThumbsDown, Sparkles, TrendingUp } from 'lucide-react'
import { search, rateAnswer, enrichKnowledgeBase, type SearchResponse, type EnrichmentResponse } from '../lib/api'

export default function SearchInterface() {
  const [query, setQuery] = useState('')
  const [isSearching, setIsSearching] = useState(false)
  const [result, setResult] = useState<SearchResponse | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [isEnriching, setIsEnriching] = useState(false)
  const [enrichmentResult, setEnrichmentResult] = useState<EnrichmentResponse | null>(null)
  const [rated, setRated] = useState(false)

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!query.trim()) return

    setIsSearching(true)
    setError(null)
    setResult(null)
    setEnrichmentResult(null)
    setRated(false)

    try {
      const response = await search(query)
      setResult(response)
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Search failed. Please try again.')
    } finally {
      setIsSearching(false)
    }
  }

  const handleRate = async (rating: number) => {
    if (!result || rated) return

    try {
      await rateAnswer(result.query_id, rating)
      setRated(true)
    } catch (err) {
      console.error('Failed to rate answer:', err)
    }
  }

  const handleEnrich = async (autoEnrich: boolean = false) => {
    if (!result) return

    setIsEnriching(true)

    try {
      const enrichment = await enrichKnowledgeBase(
        result.query,
        result.missing_info,
        autoEnrich
      )
      setEnrichmentResult(enrichment)
    } catch (err: any) {
      console.error('Enrichment failed:', err)
    } finally {
      setIsEnriching(false)
    }
  }

  const getConfidenceColor = (confidence: number): string => {
    if (confidence >= 0.8) return 'text-green-600 bg-green-100'
    if (confidence >= 0.6) return 'text-yellow-600 bg-yellow-100'
    if (confidence >= 0.4) return 'text-orange-600 bg-orange-100'
    return 'text-red-600 bg-red-100'
  }

  const getConfidenceLabel = (confidence: number): string => {
    if (confidence >= 0.8) return 'High Confidence'
    if (confidence >= 0.6) return 'Medium Confidence'
    if (confidence >= 0.4) return 'Low Confidence'
    return 'Very Low Confidence'
  }

  return (
    <div className="space-y-6">
      {/* Search Box */}
      <div className="card">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Ask a Question
        </h2>
        
        <form onSubmit={handleSearch} className="space-y-4">
          <div className="relative">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="What would you like to know? (e.g., 'What are the key findings?')"
              className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              disabled={isSearching}
            />
            <Search className="absolute right-4 top-3.5 w-5 h-5 text-gray-400" />
          </div>
          
          <button
            type="submit"
            disabled={isSearching || !query.trim()}
            className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isSearching ? (
              <>
                <Loader className="w-5 h-5 mr-2 animate-spin" />
                Searching...
              </>
            ) : (
              <>
                <Search className="w-5 h-5 mr-2" />
                Search Knowledge Base
              </>
            )}
          </button>
        </form>
      </div>

      {/* Error Message */}
      {error && (
        <div className="card bg-red-50 border-red-200">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
            <div>
              <h3 className="text-sm font-medium text-red-800">Error</h3>
              <p className="text-sm text-red-700 mt-1">{error}</p>
            </div>
          </div>
        </div>
      )}

      {/* Search Results */}
      {result && (
        <div className="space-y-6">
          {/* Answer Card */}
          <div className="card">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Answer</h3>
              
              <div className="flex items-center space-x-2">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-medium ${getConfidenceColor(result.confidence)}`}
                >
                  {getConfidenceLabel(result.confidence)} ({Math.round(result.confidence * 100)}%)
                </span>
                
                {!rated && (
                  <div className="flex items-center space-x-1 ml-4">
                    <button
                      onClick={() => handleRate(1)}
                      className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                      title="Helpful"
                    >
                      <ThumbsUp className="w-4 h-4 text-gray-600" />
                    </button>
                    <button
                      onClick={() => handleRate(-1)}
                      className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                      title="Not helpful"
                    >
                      <ThumbsDown className="w-4 h-4 text-gray-600" />
                    </button>
                  </div>
                )}
                
                {rated && (
                  <span className="text-sm text-green-600 ml-4">✓ Rated</span>
                )}
              </div>
            </div>
            
            <div className="prose max-w-none">
              <p className="text-gray-800 leading-relaxed">{result.answer}</p>
            </div>
            
            <div className="mt-4 pt-4 border-t border-gray-200 text-sm text-gray-500">
              Response time: {result.response_time.toFixed(2)}s
            </div>
          </div>

          {/* Sources */}
          {result.sources.length > 0 && (
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Sources ({result.sources.length})
              </h3>
              
              <div className="space-y-3">
                {result.sources.map((source, idx) => (
                  <div key={idx} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-900">
                        {source.document_name}
                      </span>
                      <span className="text-xs text-gray-500">
                        Relevance: {Math.round(source.relevance_score * 100)}%
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 line-clamp-3">
                      {source.chunk_text}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Missing Information & Enrichment */}
          {(result.missing_info.length > 0 || result.enrichment_suggestions.length > 0) && (
            <div className="card bg-amber-50 border-amber-200">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-lg font-semibold text-amber-900">
                  Knowledge Gaps Detected
                </h3>
                
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleEnrich(false)}
                    disabled={isEnriching}
                    className="text-sm px-3 py-1 bg-amber-600 text-white rounded-lg hover:bg-amber-700 disabled:opacity-50"
                  >
                    View Suggestions
                  </button>
                  <button
                    onClick={() => handleEnrich(true)}
                    disabled={isEnriching}
                    className="text-sm px-3 py-1 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50 flex items-center"
                  >
                    {isEnriching ? (
                      <Loader className="w-4 h-4 mr-1 animate-spin" />
                    ) : (
                      <Sparkles className="w-4 h-4 mr-1" />
                    )}
                    Auto-Enrich
                  </button>
                </div>
              </div>
              
              {result.missing_info.length > 0 && (
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-amber-900 mb-2">
                    Missing Information:
                  </h4>
                  <ul className="space-y-1">
                    {result.missing_info.map((info, idx) => (
                      <li key={idx} className="text-sm text-amber-800 flex items-start">
                        <span className="mr-2">•</span>
                        <span>{info}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {result.enrichment_suggestions.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium text-amber-900 mb-2">
                    Enrichment Suggestions:
                  </h4>
                  <ul className="space-y-1">
                    {result.enrichment_suggestions.map((suggestion, idx) => (
                      <li key={idx} className="text-sm text-amber-800 flex items-start">
                        <TrendingUp className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                        <span>{suggestion}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Enrichment Results */}
          {enrichmentResult && (
            <div className="card bg-green-50 border-green-200">
              <h3 className="text-lg font-semibold text-green-900 mb-4">
                Enrichment Analysis
                {enrichmentResult.auto_enriched && (
                  <span className="ml-2 text-sm font-normal text-green-700">
                    (Auto-enriched from Wikipedia)
                  </span>
                )}
              </h3>
              
              {enrichmentResult.new_sources.length > 0 && (
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-green-900 mb-2">
                    New Sources Added:
                  </h4>
                  <ul className="space-y-1">
                    {enrichmentResult.new_sources.map((source, idx) => (
                      <li key={idx} className="text-sm text-green-800">
                        ✓ {source}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              <div className="space-y-3">
                {enrichmentResult.suggestions.map((suggestion, idx) => (
                  <div key={idx} className="p-3 bg-white rounded-lg border border-green-200">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-green-900 capitalize">
                        {suggestion.gap_type} Gap
                      </span>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        suggestion.priority === 'high' ? 'bg-red-100 text-red-700' :
                        suggestion.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-blue-100 text-blue-700'
                      }`}>
                        {suggestion.priority} priority
                      </span>
                    </div>
                    <p className="text-sm text-green-800 mb-2">{suggestion.description}</p>
                    <div className="text-xs text-green-700">
                      <strong>Actions:</strong>
                      <ul className="mt-1 space-y-1">
                        {suggestion.suggested_actions.map((action, i) => (
                          <li key={i}>• {action}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Empty State */}
      {!result && !error && !isSearching && (
        <div className="card bg-gray-50 border-gray-200 text-center py-12">
          <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Start Your Search
          </h3>
          <p className="text-gray-600">
            Ask any question about your uploaded documents and get AI-powered answers with confidence scores and source citations.
          </p>
        </div>
      )}
    </div>
  )
}

