import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { Upload, FileText, CheckCircle, XCircle, Loader } from 'lucide-react'
import { uploadDocument } from '../lib/api'

interface UploadStatus {
  file: File
  status: 'uploading' | 'success' | 'error'
  message?: string
  progress?: number
}

export default function DocumentUpload() {
  const [uploads, setUploads] = useState<UploadStatus[]>([])

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    for (const file of acceptedFiles) {
      // Add file to uploads with uploading status
      setUploads(prev => [...prev, { file, status: 'uploading', progress: 0 }])

      try {
        const result = await uploadDocument(file)
        
        setUploads(prev =>
          prev.map(u =>
            u.file === file
              ? {
                  ...u,
                  status: 'success',
                  message: `Processed ${result.num_chunks} chunks`,
                }
              : u
          )
        )
      } catch (error: any) {
        setUploads(prev =>
          prev.map(u =>
            u.file === file
              ? {
                  ...u,
                  status: 'error',
                  message: error.response?.data?.detail || 'Upload failed',
                }
              : u
          )
        )
      }
    }
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
    },
    maxSize: 52428800, // 50MB
  })

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
  }

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <div className="card">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Upload Documents
        </h2>
        
        <div
          {...getRootProps()}
          className={`
            border-2 border-dashed rounded-lg p-12 text-center cursor-pointer
            transition-colors duration-200
            ${isDragActive
              ? 'border-primary-500 bg-primary-50'
              : 'border-gray-300 hover:border-primary-400 bg-gray-50'
            }
          `}
        >
          <input {...getInputProps()} />
          
          <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          
          {isDragActive ? (
            <p className="text-lg text-primary-600 font-medium">
              Drop the files here...
            </p>
          ) : (
            <>
              <p className="text-lg text-gray-700 font-medium mb-2">
                Drag & drop files here, or click to select
              </p>
              <p className="text-sm text-gray-500">
                Supports PDF, DOCX, TXT, MD (max 50MB)
              </p>
            </>
          )}
        </div>
      </div>

      {/* Upload Status */}
      {uploads.length > 0 && (
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Upload Status
          </h3>
          
          <div className="space-y-3">
            {uploads.map((upload, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center space-x-3 flex-1">
                  <FileText className="w-5 h-5 text-gray-400" />
                  
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {upload.file.name}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatFileSize(upload.file.size)}
                      {upload.message && ` • ${upload.message}`}
                    </p>
                  </div>
                </div>

                <div className="ml-4">
                  {upload.status === 'uploading' && (
                    <Loader className="w-5 h-5 text-primary-600 animate-spin" />
                  )}
                  {upload.status === 'success' && (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  )}
                  {upload.status === 'error' && (
                    <XCircle className="w-5 h-5 text-red-600" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Instructions */}
      <div className="card bg-blue-50 border-blue-200">
        <h3 className="text-lg font-semibold text-blue-900 mb-2">
          How it works
        </h3>
        <ul className="space-y-2 text-sm text-blue-800">
          <li className="flex items-start">
            <span className="mr-2">1.</span>
            <span>Upload your documents (PDF, DOCX, TXT, or MD files)</span>
          </li>
          <li className="flex items-start">
            <span className="mr-2">2.</span>
            <span>Documents are automatically processed, chunked, and indexed</span>
          </li>
          <li className="flex items-start">
            <span className="mr-2">3.</span>
            <span>Use the Search tab to ask questions about your documents</span>
          </li>
          <li className="flex items-start">
            <span className="mr-2">4.</span>
            <span>Get AI-powered answers with source citations and confidence scores</span>
          </li>
        </ul>
      </div>
    </div>
  )
}

