"""Local LLM service for demo mode (fallback when OpenAI unavailable)"""

import logging
from typing import Dict, Any, List
import json

logger = logging.getLogger(__name__)


class LocalLLMService:
    """Simple local answer generation for demo purposes"""
    
    def generate_answer(
        self,
        query: str,
        retrieved_chunks: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Generate answer using simple extraction (demo mode)
        
        Args:
            query: User's search query
            retrieved_chunks: List of retrieved chunks with metadata
            
        Returns:
            Dictionary with answer, confidence, missing_info, and enrichment suggestions
        """
        logger.info(f"🤖 Using LOCAL demo mode for query: {query}")
        
        if not retrieved_chunks:
            return {
                'answer': "No relevant information found in the knowledge base.",
                'confidence': 0.0,
                'sources_used': [],
                'missing_info': ["No documents available to answer this question"],
                'enrichment_suggestions': [f"Upload documents related to: {query}"],
                'source_details': []
            }
        
        # Simple answer generation from chunks
        answer_parts = []
        sources_used = []
        
        for i, chunk in enumerate(retrieved_chunks[:3], 1):  # Use top 3 chunks
            text = chunk.get('chunk_text', '')
            metadata = chunk.get('metadata', {})
            filename = metadata.get('filename', 'Unknown')
            
            # Extract relevant sentences (simple approach)
            sentences = text.split('. ')
            relevant_sentences = [s for s in sentences if any(word.lower() in s.lower() for word in query.split()[:3])]
            
            if relevant_sentences:
                answer_parts.extend(relevant_sentences[:2])  # Max 2 sentences per chunk
                sources_used.append(f"Source {i}")
        
        # Calculate average relevance score
        relevance_scores = []
        for chunk in retrieved_chunks:
            distance = chunk.get('distance', 1.0)
            relevance = 1.0 - distance if distance is not None else 0.0
            relevance_scores.append(relevance)
        
        avg_relevance = sum(relevance_scores) / len(relevance_scores) if relevance_scores else 0.0
        max_relevance = max(relevance_scores) if relevance_scores else 0.0
        
        # Build answer
        if answer_parts:
            answer = '. '.join(answer_parts)
            if not answer.endswith('.'):
                answer += '.'
            base_confidence = min(0.85, 0.5 + (len(answer_parts) * 0.15))  # Simple confidence
            
            # Adjust based on relevance scores
            if max_relevance < 0.4:
                confidence = min(base_confidence * 0.4, 0.3)
            elif avg_relevance < 0.5:
                confidence = base_confidence * 0.6
            elif avg_relevance < 0.7:
                confidence = base_confidence * 0.8
            else:
                confidence = base_confidence * 0.95
        else:
            # Fallback: use first chunk but with low confidence if relevance is low
            answer = retrieved_chunks[0].get('chunk_text', '')[:300] + "..."
            base_confidence = 0.6
            
            # Heavily penalize low relevance for fallback answers
            if max_relevance < 0.5:
                confidence = min(base_confidence * 0.5, 0.35)
            else:
                confidence = base_confidence * 0.7
            
            sources_used = ["Source 1"]
        
        # Detect missing info
        missing_info = []
        query_lower = query.lower()
        
        if any(word in query_lower for word in ['when', 'date', 'time', 'year']):
            if not any(word in answer.lower() for word in ['year', 'date', '20', '19']):
                missing_info.append("Specific dates and timelines are not available in the documents")
        
        if any(word in query_lower for word in ['how many', 'how much', 'cost', 'price']):
            if not any(char.isdigit() for char in answer):
                missing_info.append("Quantitative data and specific numbers are missing")
        
        if any(word in query_lower for word in ['why', 'reason', 'because']):
            if 'because' not in answer.lower() and 'reason' not in answer.lower():
                missing_info.append("Detailed explanations and reasoning are limited")
        
        # Generate enrichment suggestions
        enrichment_suggestions = []
        if len(retrieved_chunks) < 2:
            enrichment_suggestions.append("Upload more documents for better coverage")
        if confidence < 0.7:
            enrichment_suggestions.append(f"Add documents specifically about: {query}")
        if missing_info:
            enrichment_suggestions.append("Consider uploading more detailed documentation or reports")
        
        # Extract source details
        source_details = []
        for chunk in retrieved_chunks:
            metadata = chunk.get('metadata', {})
            source = {
                'document_id': metadata.get('document_id'),
                'filename': metadata.get('filename', 'Unknown'),
                'chunk_index': metadata.get('chunk_index'),
                'relevance_score': 1.0 - chunk.get('distance', 0.3) if chunk.get('distance') is not None else 0.7
            }
            source_details.append(source)
        
        result = {
            'answer': answer,
            'confidence': confidence,
            'sources_used': sources_used,
            'missing_info': missing_info,
            'enrichment_suggestions': enrichment_suggestions,
            'source_details': source_details,
            'completeness_score': confidence
        }
        
        logger.info(f"✅ LOCAL answer generated with confidence: {confidence:.2f}")
        return result


# Global instance
local_llm_service = LocalLLMService()

