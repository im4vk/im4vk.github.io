"""Vector store service using ChromaDB"""

import logging
from typing import List, Dict, Any, Optional
import chromadb
from chromadb.config import Settings
from app.config import settings

logger = logging.getLogger(__name__)


class VectorStore:
    """Manage vector storage and retrieval using ChromaDB"""
    
    def __init__(self):
        self.client = chromadb.Client(Settings(
            persist_directory=settings.chroma_persist_directory,
            anonymized_telemetry=False
        ))
        
        # Create or get collection
        self.collection = self.client.get_or_create_collection(
            name="knowledge_base",
            metadata={"description": "AI Knowledge Base document chunks"}
        )
        
        logger.info(f"Vector store initialized with collection: knowledge_base")
    
    def add_chunks(
        self,
        chunks: List[str],
        embeddings: List[List[float]],
        metadatas: List[Dict[str, Any]],
        ids: List[str]
    ):
        """
        Add document chunks to vector store
        
        Args:
            chunks: List of text chunks
            embeddings: List of embedding vectors
            metadatas: List of metadata dictionaries
            ids: List of unique IDs for each chunk
        """
        try:
            self.collection.add(
                documents=chunks,
                embeddings=embeddings,
                metadatas=metadatas,
                ids=ids
            )
            logger.info(f"Added {len(chunks)} chunks to vector store")
        except Exception as e:
            logger.error(f"Error adding chunks to vector store: {str(e)}")
            raise
    
    def search(
        self,
        query_embedding: List[float],
        top_k: int = 5,
        filter_dict: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Search for similar chunks using vector similarity
        
        Args:
            query_embedding: Query embedding vector
            top_k: Number of results to return
            filter_dict: Optional metadata filter
            
        Returns:
            Dictionary with search results
        """
        try:
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k,
                where=filter_dict if filter_dict else None
            )
            
            logger.info(f"Found {len(results['documents'][0])} results")
            return results
            
        except Exception as e:
            logger.error(f"Error searching vector store: {str(e)}")
            raise
    
    def delete_by_document_id(self, document_id: int):
        """
        Delete all chunks for a specific document
        
        Args:
            document_id: Document ID to delete
        """
        try:
            # Get all chunks for this document
            results = self.collection.get(
                where={"document_id": document_id}
            )
            
            if results['ids']:
                self.collection.delete(ids=results['ids'])
                logger.info(f"Deleted {len(results['ids'])} chunks for document {document_id}")
            
        except Exception as e:
            logger.error(f"Error deleting chunks: {str(e)}")
            raise
    
    def get_stats(self) -> Dict[str, Any]:
        """Get vector store statistics"""
        try:
            count = self.collection.count()
            return {
                "total_chunks": count,
                "collection_name": self.collection.name
            }
        except Exception as e:
            logger.error(f"Error getting stats: {str(e)}")
            return {"total_chunks": 0, "error": str(e)}
    
    def clear_all(self):
        """Clear all data from vector store (use with caution!)"""
        try:
            self.client.delete_collection("knowledge_base")
            self.collection = self.client.create_collection(
                name="knowledge_base",
                metadata={"description": "AI Knowledge Base document chunks"}
            )
            logger.warning("Vector store cleared!")
        except Exception as e:
            logger.error(f"Error clearing vector store: {str(e)}")
            raise


# Global instance
vector_store = VectorStore()

