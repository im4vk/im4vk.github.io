"""RAG Pipeline - orchestrates document processing, chunking, embedding, and storage"""

import logging
from typing import Dict, Any, List
from sqlalchemy.orm import Session

from app.database import Document as DBDocument, Chunk as DBChunk
from app.services.document_processor import document_processor
from app.services.chunker import text_chunker
from app.services.embeddings import embedding_service
from app.services.vector_store import vector_store
from app.config import settings

logger = logging.getLogger(__name__)


class RAGPipeline:
    """End-to-end RAG pipeline for document processing"""
    
    def __init__(self):
        self.doc_processor = document_processor
        self.chunker = text_chunker
        self.embedder = embedding_service
        self.vector_store = vector_store
    
    async def process_document(
        self,
        document_id: int,
        file_path: str,
        filename: str,
        db: Session
    ) -> Dict[str, Any]:
        """
        Process a document through the full RAG pipeline
        
        Args:
            document_id: Database document ID
            file_path: Path to the document file
            filename: Original filename
            db: Database session
            
        Returns:
            Processing result dictionary
        """
        try:
            # Get document from database
            db_document = db.query(DBDocument).filter(DBDocument.id == document_id).first()
            if not db_document:
                raise ValueError(f"Document {document_id} not found in database")
            
            # Update status
            db_document.status = "processing"
            db.commit()
            
            # Step 1: Extract text from document
            logger.info(f"Extracting text from {filename}...")
            text, metadata = self.doc_processor.process_document(file_path, filename)
            
            if not text.strip():
                db_document.status = "failed"
                db.commit()
                raise ValueError("No text extracted from document")
            
            # Step 2: Chunk the text
            logger.info(f"Chunking text for {filename}...")
            chunks = self.chunker.chunk_text(
                text,
                metadata={
                    'document_id': document_id,
                    'filename': filename,
                    'file_type': metadata['file_type']
                }
            )
            
            if not chunks:
                db_document.status = "failed"
                db.commit()
                raise ValueError("No chunks created from document")
            
            # Step 3: Generate embeddings
            logger.info(f"Generating embeddings for {len(chunks)} chunks...")
            chunk_texts = [chunk['text'] for chunk in chunks]
            embeddings = self.embedder.generate_embeddings_batch(chunk_texts)
            
            # Step 4: Store in vector database
            logger.info(f"Storing chunks in vector database...")
            chunk_ids = [f"doc_{document_id}_chunk_{i}" for i in range(len(chunks))]
            
            chunk_metadatas = []
            for chunk in chunks:
                chunk_meta = {
                    'document_id': document_id,
                    'filename': filename,
                    'file_type': chunk.get('file_type', ''),
                    'chunk_index': chunk['chunk_index'],
                    'total_chunks': chunk['total_chunks'],
                    'token_count': chunk['token_count']
                }
                chunk_metadatas.append(chunk_meta)
            
            self.vector_store.add_chunks(
                chunks=chunk_texts,
                embeddings=embeddings,
                metadatas=chunk_metadatas,
                ids=chunk_ids
            )
            
            # Step 5: Store chunk references in database
            logger.info(f"Storing chunk references in database...")
            for i, chunk in enumerate(chunks):
                db_chunk = DBChunk(
                    document_id=document_id,
                    content=chunk['text'][:1000],  # Store preview (first 1000 chars)
                    chunk_index=chunk['chunk_index'],
                    page_number=metadata.get('page_number')
                )
                db.add(db_chunk)
            
            # Update document status
            db_document.status = "completed"
            db_document.num_chunks = len(chunks)
            db.commit()
            
            logger.info(f"Successfully processed {filename}: {len(chunks)} chunks")
            
            return {
                'document_id': document_id,
                'filename': filename,
                'status': 'completed',
                'num_chunks': len(chunks),
                'total_tokens': sum(chunk['token_count'] for chunk in chunks)
            }
        
        except Exception as e:
            logger.error(f"Error processing document {document_id}: {str(e)}", exc_info=True)
            
            # Update document status to failed
            if db_document:
                db_document.status = "failed"
                db.commit()
            
            raise
    
    def search(
        self,
        query: str,
        top_k: int = None,
        filter_dict: Dict[str, Any] = None
    ) -> List[Dict[str, Any]]:
        """
        Search for relevant chunks
        
        Args:
            query: Search query
            top_k: Number of results to return
            filter_dict: Optional metadata filter
            
        Returns:
            List of search results with chunks and metadata
        """
        top_k = top_k or settings.top_k_retrieval
        
        try:
            # Generate query embedding
            logger.info(f"Searching for: {query}")
            query_embedding = self.embedder.generate_query_embedding(query)
            
            # Search vector store
            results = self.vector_store.search(
                query_embedding=query_embedding,
                top_k=top_k,
                filter_dict=filter_dict
            )
            
            # Format results
            formatted_results = []
            
            if results['documents'] and results['documents'][0]:
                for i in range(len(results['documents'][0])):
                    result = {
                        'chunk_text': results['documents'][0][i],
                        'metadata': results['metadatas'][0][i] if results['metadatas'] else {},
                        'distance': results['distances'][0][i] if results['distances'] else None,
                        'id': results['ids'][0][i] if results['ids'] else None
                    }
                    formatted_results.append(result)
            
            logger.info(f"Found {len(formatted_results)} results")
            return formatted_results
        
        except Exception as e:
            logger.error(f"Error searching: {str(e)}")
            raise


# Global instance
rag_pipeline = RAGPipeline()

