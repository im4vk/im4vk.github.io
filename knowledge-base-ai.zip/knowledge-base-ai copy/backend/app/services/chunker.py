"""Text chunking service - splits documents into semantic chunks"""

import logging
import re
from typing import List, Dict, Any
import tiktoken
from app.config import settings

logger = logging.getLogger(__name__)


class TextChunker:
    """Split text into semantic chunks with overlap"""
    
    def __init__(
        self,
        chunk_size: int = None,
        chunk_overlap: int = None,
        encoding_name: str = "cl100k_base"
    ):
        self.chunk_size = chunk_size or settings.chunk_size
        self.chunk_overlap = chunk_overlap or settings.chunk_overlap
        
        # Initialize tokenizer
        try:
            self.encoding = tiktoken.get_encoding(encoding_name)
        except Exception as e:
            logger.warning(f"Failed to load encoding {encoding_name}, using default: {str(e)}")
            self.encoding = tiktoken.get_encoding("cl100k_base")
    
    def count_tokens(self, text: str) -> int:
        """Count tokens in text"""
        return len(self.encoding.encode(text))
    
    def chunk_text(self, text: str, metadata: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Split text into chunks with metadata
        
        Args:
            text: Text to chunk
            metadata: Optional metadata to attach to each chunk
            
        Returns:
            List of chunk dictionaries with text and metadata
        """
        if not text or not text.strip():
            return []
        
        # First, split by paragraphs
        paragraphs = self._split_into_paragraphs(text)
        
        chunks = []
        current_chunk = []
        current_length = 0
        
        for para in paragraphs:
            para_tokens = self.count_tokens(para)
            
            # If single paragraph exceeds chunk size, split it further
            if para_tokens > self.chunk_size:
                # Save current chunk if exists
                if current_chunk:
                    chunks.append('\n\n'.join(current_chunk))
                    current_chunk = []
                    current_length = 0
                
                # Split large paragraph by sentences
                sub_chunks = self._chunk_large_paragraph(para)
                chunks.extend(sub_chunks)
                continue
            
            # Check if adding this paragraph would exceed chunk size
            if current_length + para_tokens > self.chunk_size and current_chunk:
                # Save current chunk
                chunks.append('\n\n'.join(current_chunk))
                
                # Start new chunk with overlap
                overlap_text = self._get_overlap_text(current_chunk)
                current_chunk = [overlap_text, para] if overlap_text else [para]
                current_length = self.count_tokens('\n\n'.join(current_chunk))
            else:
                # Add paragraph to current chunk
                current_chunk.append(para)
                current_length += para_tokens
        
        # Add remaining chunk
        if current_chunk:
            chunks.append('\n\n'.join(current_chunk))
        
        # Create chunk dictionaries with metadata
        result = []
        for idx, chunk_text in enumerate(chunks):
            chunk_dict = {
                'text': chunk_text,
                'chunk_index': idx,
                'total_chunks': len(chunks),
                'token_count': self.count_tokens(chunk_text)
            }
            
            # Add provided metadata
            if metadata:
                chunk_dict.update(metadata)
            
            result.append(chunk_dict)
        
        logger.info(f"Created {len(result)} chunks from text of {self.count_tokens(text)} tokens")
        return result
    
    def _split_into_paragraphs(self, text: str) -> List[str]:
        """Split text into paragraphs"""
        # Split by double newlines or more
        paragraphs = re.split(r'\n\s*\n', text)
        
        # Filter out empty paragraphs and strip whitespace
        paragraphs = [p.strip() for p in paragraphs if p.strip()]
        
        return paragraphs
    
    def _chunk_large_paragraph(self, paragraph: str) -> List[str]:
        """Split a large paragraph into smaller chunks by sentences"""
        # Split by sentences
        sentences = re.split(r'(?<=[.!?])\s+', paragraph)
        
        chunks = []
        current_chunk = []
        current_length = 0
        
        for sentence in sentences:
            sentence_tokens = self.count_tokens(sentence)
            
            # If single sentence exceeds chunk size, split by words
            if sentence_tokens > self.chunk_size:
                if current_chunk:
                    chunks.append(' '.join(current_chunk))
                    current_chunk = []
                    current_length = 0
                
                # Split by words
                word_chunks = self._chunk_by_words(sentence)
                chunks.extend(word_chunks)
                continue
            
            if current_length + sentence_tokens > self.chunk_size and current_chunk:
                chunks.append(' '.join(current_chunk))
                
                # Start new chunk with overlap
                overlap = self._get_sentence_overlap(current_chunk)
                current_chunk = overlap + [sentence]
                current_length = self.count_tokens(' '.join(current_chunk))
            else:
                current_chunk.append(sentence)
                current_length += sentence_tokens
        
        if current_chunk:
            chunks.append(' '.join(current_chunk))
        
        return chunks
    
    def _chunk_by_words(self, text: str) -> List[str]:
        """Split text by words when sentences are too long"""
        words = text.split()
        chunks = []
        current_chunk = []
        current_length = 0
        
        for word in words:
            word_tokens = self.count_tokens(word)
            
            if current_length + word_tokens > self.chunk_size and current_chunk:
                chunks.append(' '.join(current_chunk))
                
                # Keep last few words for overlap
                overlap_size = min(20, len(current_chunk) // 4)
                current_chunk = current_chunk[-overlap_size:] + [word]
                current_length = self.count_tokens(' '.join(current_chunk))
            else:
                current_chunk.append(word)
                current_length += word_tokens
        
        if current_chunk:
            chunks.append(' '.join(current_chunk))
        
        return chunks
    
    def _get_overlap_text(self, paragraphs: List[str]) -> str:
        """Get overlap text from previous chunk (last paragraph)"""
        if not paragraphs:
            return ""
        
        # Take last paragraph for overlap
        last_para = paragraphs[-1]
        tokens = self.count_tokens(last_para)
        
        # If last paragraph is too long, take only part of it
        if tokens > self.chunk_overlap:
            sentences = re.split(r'(?<=[.!?])\s+', last_para)
            overlap_sentences = []
            overlap_tokens = 0
            
            # Take last sentences until we reach overlap size
            for sentence in reversed(sentences):
                sent_tokens = self.count_tokens(sentence)
                if overlap_tokens + sent_tokens > self.chunk_overlap:
                    break
                overlap_sentences.insert(0, sentence)
                overlap_tokens += sent_tokens
            
            return ' '.join(overlap_sentences) if overlap_sentences else ""
        
        return last_para
    
    def _get_sentence_overlap(self, sentences: List[str]) -> List[str]:
        """Get sentence overlap for continuation"""
        if not sentences:
            return []
        
        overlap = []
        overlap_tokens = 0
        
        for sentence in reversed(sentences):
            sent_tokens = self.count_tokens(sentence)
            if overlap_tokens + sent_tokens > self.chunk_overlap:
                break
            overlap.insert(0, sentence)
            overlap_tokens += sent_tokens
        
        return overlap


# Global instance
text_chunker = TextChunker()

