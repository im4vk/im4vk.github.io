"""Embedding service using OpenAI embeddings API with local fallback"""

import logging
from typing import List, Dict, Any
import openai
from openai import OpenAI
from app.config import settings
import time

logger = logging.getLogger(__name__)


class EmbeddingService:
    """Generate embeddings using OpenAI API with automatic fallback to local models"""
    
    def __init__(self):
        self.client = None
        self.use_local = settings.use_local_models
        self.local_service = None
        
        # Try to initialize OpenAI client
        try:
            if settings.openai_api_key and settings.openai_api_key != "demo-mode":
                self.client = OpenAI(api_key=settings.openai_api_key)
                logger.info("✅ OpenAI client initialized (will fallback to local if quota exceeded)")
            else:
                logger.info("⚠️ No OpenAI key, using local models")
                self.use_local = True
        except Exception as e:
            logger.warning(f"OpenAI initialization failed, using local models: {e}")
            self.use_local = True
        
        self.model = settings.embedding_model
        self.batch_size = 100  # OpenAI allows up to 2048, but we use 100 for safety
    
    def _get_local_service(self):
        """Lazy load local embedding service"""
        if self.local_service is None:
            from app.services.local_embeddings import local_embedding_service
            self.local_service = local_embedding_service
        return self.local_service
    
    def _should_use_local(self) -> bool:
        """Determine if we should use local models"""
        return self.use_local or self.client is None
    
    def generate_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for a single text (with automatic fallback)
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
        """
        # Try local first if enabled
        if self._should_use_local():
            try:
                return self._get_local_service().generate_embedding(text)
            except Exception as e:
                logger.error(f"Local embedding failed: {e}")
                raise
        
        # Try OpenAI
        try:
            response = self.client.embeddings.create(
                model=self.model,
                input=text
            )
            return response.data[0].embedding
        
        except openai.RateLimitError as e:
            logger.warning(f"⚠️ OpenAI quota exceeded, switching to local models: {str(e)}")
            self.use_local = True
            return self._get_local_service().generate_embedding(text)
        
        except Exception as e:
            logger.error(f"Error generating embedding, trying local fallback: {str(e)}")
            try:
                self.use_local = True
                return self._get_local_service().generate_embedding(text)
            except:
                raise Exception(f"Both OpenAI and local embeddings failed: {str(e)}")
    
    def generate_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts in batches (with automatic fallback)
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of embedding vectors
        """
        if not texts:
            return []
        
        # Try local first if enabled
        if self._should_use_local():
            try:
                return self._get_local_service().generate_embeddings_batch(texts)
            except Exception as e:
                logger.error(f"Local batch embedding failed: {e}")
                raise
        
        all_embeddings = []
        
        # Try OpenAI - Process in batches
        for i in range(0, len(texts), self.batch_size):
            batch = texts[i:i + self.batch_size]
            
            try:
                start_time = time.time()
                response = self.client.embeddings.create(
                    model=self.model,
                    input=batch
                )
                
                # Extract embeddings in order
                batch_embeddings = [data.embedding for data in response.data]
                all_embeddings.extend(batch_embeddings)
                
                elapsed = time.time() - start_time
                logger.info(f"Generated {len(batch)} OpenAI embeddings in {elapsed:.2f}s")
                
            except openai.RateLimitError as e:
                logger.warning(f"⚠️ OpenAI quota exceeded at batch {i}, switching to local models")
                self.use_local = True
                # Process remaining with local
                remaining = texts[i:]
                remaining_embeddings = self._get_local_service().generate_embeddings_batch(remaining)
                all_embeddings.extend(remaining_embeddings)
                break
                
            except Exception as e:
                logger.error(f"Error generating batch embeddings, trying local fallback: {str(e)}")
                try:
                    self.use_local = True
                    remaining = texts[i:]
                    remaining_embeddings = self._get_local_service().generate_embeddings_batch(remaining)
                    all_embeddings.extend(remaining_embeddings)
                    break
                except:
                    raise Exception(f"Both OpenAI and local embeddings failed: {str(e)}")
        
        return all_embeddings
    
    def generate_query_embedding(self, query: str) -> List[float]:
        """
        Generate embedding for a search query
        (Alias for generate_embedding for clarity)
        
        Args:
            query: Search query
            
        Returns:
            Query embedding vector
        """
        return self.generate_embedding(query)


# Global instance
embedding_service = EmbeddingService()

