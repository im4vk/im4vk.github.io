"""LLM service for answer generation and completeness detection with local fallback"""

import logging
import json
from typing import Dict, Any, List
import openai
from openai import OpenAI
from app.config import settings

logger = logging.getLogger(__name__)


class LLMService:
    """Handle LLM interactions for answer generation with automatic fallback"""
    
    def __init__(self):
        self.client = None
        self.use_local = settings.use_local_models
        self.local_service = None
        
        # Try to initialize OpenAI client
        try:
            if settings.openai_api_key and settings.openai_api_key != "demo-mode":
                self.client = OpenAI(api_key=settings.openai_api_key)
                logger.info("✅ OpenAI LLM client initialized (will fallback to local if quota exceeded)")
            else:
                logger.info("⚠️ No OpenAI key, using local LLM")
                self.use_local = True
        except Exception as e:
            logger.warning(f"OpenAI LLM initialization failed, using local: {e}")
            self.use_local = True
        
        self.model = settings.llm_model
    
    def _get_local_service(self):
        """Lazy load local LLM service"""
        if self.local_service is None:
            from app.services.local_llm import local_llm_service
            self.local_service = local_llm_service
        return self.local_service
    
    def generate_answer(
        self,
        query: str,
        retrieved_chunks: List[Dict[str, Any]],
        temperature: float = None
    ) -> Dict[str, Any]:
        """
        Generate an answer with completeness detection (with automatic fallback)
        
        Args:
            query: User's search query
            retrieved_chunks: List of retrieved chunks with metadata
            temperature: Optional temperature override
            
        Returns:
            Dictionary with answer, confidence, missing_info, and enrichment suggestions
        """
        # Try local first if enabled
        if self.use_local or self.client is None:
            try:
                return self._get_local_service().generate_answer(query, retrieved_chunks)
            except Exception as e:
                logger.error(f"Local LLM failed: {e}")
                raise
        
        temperature = temperature or settings.temperature
        
        # Format context from retrieved chunks
        context = self._format_context(retrieved_chunks)
        
        # Create prompt
        prompt = self._create_answer_prompt(query, context)
        
        try:
            logger.info(f"Generating OpenAI answer for query: {query}")
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an AI assistant that analyzes documents to answer questions. You provide structured responses with confidence scores and identify missing information."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=temperature,
                response_format={"type": "json_object"}
            )
            
            # Parse response
            content = response.choices[0].message.content
            result = json.loads(content)
            
            # Validate and enhance result
            validated_result = self._validate_result(result, retrieved_chunks)
            
            logger.info(f"Generated answer with confidence: {validated_result.get('confidence', 0)}")
            return validated_result
        
        except openai.RateLimitError as e:
            logger.warning(f"⚠️ OpenAI quota exceeded, switching to local LLM: {str(e)}")
            self.use_local = True
            return self._get_local_service().generate_answer(query, retrieved_chunks)
        
        except Exception as e:
            logger.error(f"Error generating answer, trying local fallback: {str(e)}", exc_info=True)
            try:
                self.use_local = True
                return self._get_local_service().generate_answer(query, retrieved_chunks)
            except:
                raise Exception(f"Both OpenAI and local LLM failed: {str(e)}")
    
    def _format_context(self, retrieved_chunks: List[Dict[str, Any]]) -> str:
        """Format retrieved chunks into context string"""
        context_parts = []
        
        for i, chunk in enumerate(retrieved_chunks, 1):
            metadata = chunk.get('metadata', {})
            filename = metadata.get('filename', 'Unknown')
            chunk_index = metadata.get('chunk_index', '?')
            
            context_parts.append(
                f"[Source {i}: {filename} (Chunk {chunk_index})]\n{chunk['chunk_text']}\n"
            )
        
        return "\n".join(context_parts)
    
    def _create_answer_prompt(self, query: str, context: str) -> str:
        """Create prompt for answer generation"""
        return f"""You are analyzing documents to answer a user's question. 

Context from documents:
{context}

User Question: {query}

Provide a comprehensive answer in the following JSON format:
{{
  "answer": "Detailed answer based on the documents. Only use information from the provided context. If information is incomplete, explicitly state what is missing or uncertain.",
  "confidence": 0.0-1.0,
  "sources_used": ["Source 1", "Source 2", ...],
  "missing_info": ["Specific information that is missing or uncertain", "What gaps exist in the available data"],
  "enrichment_suggestions": ["What additional documents or data would help complete the answer", "Specific topics or areas that need more coverage"]
}}

Rules for generating your response:
1. **Answer**: Only use information explicitly stated in the provided context. Do not hallucinate or infer beyond what's written.
2. **Confidence** (0.0-1.0):
   - 0.9-1.0: Complete, well-supported answer with multiple sources
   - 0.7-0.8: Good answer but some minor gaps or single source
   - 0.5-0.6: Partial answer with significant gaps
   - 0.3-0.4: Very limited information available
   - 0.0-0.2: Insufficient information to answer
3. **Sources Used**: List which sources (by number) you used
4. **Missing Info**: Be specific about what information is absent or unclear
5. **Enrichment Suggestions**: Provide actionable suggestions for improving the knowledge base

If the context has no relevant information, set confidence to 0.0 and explain what's needed."""
    
    def _validate_result(self, result: Dict[str, Any], retrieved_chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Validate and enhance LLM result"""
        
        # Ensure required fields exist
        validated = {
            'answer': result.get('answer', 'Unable to generate answer'),
            'confidence': float(result.get('confidence', 0.0)),
            'sources_used': result.get('sources_used', []),
            'missing_info': result.get('missing_info', []),
            'enrichment_suggestions': result.get('enrichment_suggestions', [])
        }
        
        # Add source details first (needed for confidence adjustment)
        validated['source_details'] = self._extract_source_details(retrieved_chunks)
        
        # Adjust confidence based on relevance scores
        validated['confidence'] = self._adjust_confidence_by_relevance(
            validated['confidence'], 
            validated['source_details']
        )
        
        # Clamp confidence to valid range
        validated['confidence'] = max(0.0, min(1.0, validated['confidence']))
        
        # Calculate completeness score
        validated['completeness_score'] = self._calculate_completeness(validated)
        
        return validated
    
    def _extract_source_details(self, retrieved_chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Extract detailed source information"""
        source_details = []
        
        for chunk in retrieved_chunks:
            metadata = chunk.get('metadata', {})
            
            source = {
                'document_id': metadata.get('document_id'),
                'filename': metadata.get('filename', 'Unknown'),
                'chunk_index': metadata.get('chunk_index'),
                'relevance_score': 1.0 - chunk.get('distance', 0.0) if chunk.get('distance') is not None else None
            }
            source_details.append(source)
        
        return source_details
    
    def _adjust_confidence_by_relevance(
        self, 
        llm_confidence: float, 
        source_details: List[Dict[str, Any]]
    ) -> float:
        """
        Adjust LLM confidence based on actual relevance scores from vector search
        
        If retrieved chunks have low relevance, confidence should be lowered
        even if LLM is confident in its answer.
        """
        if not source_details:
            return 0.0
        
        # Calculate average relevance score
        relevance_scores = [
            s.get('relevance_score', 0.0) 
            for s in source_details 
            if s.get('relevance_score') is not None
        ]
        
        if not relevance_scores:
            return llm_confidence * 0.5  # Penalize if no relevance scores
        
        avg_relevance = sum(relevance_scores) / len(relevance_scores)
        max_relevance = max(relevance_scores)
        
        # Relevance thresholds
        # High relevance (>0.7): No penalty
        # Medium relevance (0.4-0.7): Moderate penalty
        # Low relevance (<0.4): Strong penalty
        
        if max_relevance < 0.4:
            # Very low relevance - cap confidence at 0.3
            adjusted = min(llm_confidence * 0.4, 0.3)
            logger.info(f"Low relevance detected (max: {max_relevance:.2f}), capping confidence at {adjusted:.2f}")
        elif avg_relevance < 0.5:
            # Low-medium relevance - reduce by 40%
            adjusted = llm_confidence * 0.6
            logger.info(f"Medium-low relevance (avg: {avg_relevance:.2f}), reducing confidence to {adjusted:.2f}")
        elif avg_relevance < 0.7:
            # Medium relevance - reduce by 20%
            adjusted = llm_confidence * 0.8
        else:
            # High relevance - minimal reduction
            adjusted = llm_confidence * 0.95
        
        return adjusted
    
    def _calculate_completeness(self, result: Dict[str, Any]) -> float:
        """
        Calculate completeness score based on multiple factors
        
        Returns value between 0.0 and 1.0
        """
        confidence = result.get('confidence', 0.0)
        missing_info_count = len(result.get('missing_info', []))
        sources_count = len(result.get('sources_used', []))
        
        # Base score from confidence
        score = confidence * 0.6
        
        # Penalty for missing information
        missing_penalty = min(0.3, missing_info_count * 0.1)
        score -= missing_penalty
        
        # Bonus for multiple sources
        source_bonus = min(0.2, sources_count * 0.05)
        score += source_bonus
        
        # Clamp to valid range
        return max(0.0, min(1.0, score))
    
    def detect_knowledge_gaps(
        self,
        query: str,
        answer_result: Dict[str, Any],
        confidence_threshold: float = None
    ) -> Dict[str, Any]:
        """
        Analyze knowledge gaps and categorize them
        
        Args:
            query: Original query
            answer_result: Result from generate_answer
            confidence_threshold: Minimum confidence threshold
            
        Returns:
            Gap analysis with categorized gaps
        """
        threshold = confidence_threshold or settings.min_confidence_threshold
        
        confidence = answer_result.get('confidence', 0.0)
        missing_info = answer_result.get('missing_info', [])
        
        # Determine if enrichment is needed
        needs_enrichment = confidence < threshold or len(missing_info) > 0
        
        # Categorize gaps
        gap_categories = self._categorize_gaps(missing_info)
        
        return {
            'needs_enrichment': needs_enrichment,
            'confidence': confidence,
            'threshold': threshold,
            'gap_categories': gap_categories,
            'priority': self._determine_priority(confidence, len(missing_info))
        }
    
    def _categorize_gaps(self, missing_info: List[str]) -> Dict[str, List[str]]:
        """Categorize missing information into types"""
        categories = {
            'factual': [],
            'temporal': [],
            'contextual': [],
            'quantitative': [],
            'other': []
        }
        
        # Simple keyword-based categorization
        for info in missing_info:
            info_lower = info.lower()
            
            if any(word in info_lower for word in ['when', 'date', 'time', 'year', 'period']):
                categories['temporal'].append(info)
            elif any(word in info_lower for word in ['how many', 'how much', 'number', 'amount', 'percentage']):
                categories['quantitative'].append(info)
            elif any(word in info_lower for word in ['what', 'who', 'which', 'definition']):
                categories['factual'].append(info)
            elif any(word in info_lower for word in ['why', 'how', 'context', 'background', 'reason']):
                categories['contextual'].append(info)
            else:
                categories['other'].append(info)
        
        # Remove empty categories
        return {k: v for k, v in categories.items() if v}
    
    def _determine_priority(self, confidence: float, missing_count: int) -> str:
        """Determine enrichment priority"""
        if confidence < 0.3 or missing_count > 5:
            return 'high'
        elif confidence < 0.6 or missing_count > 2:
            return 'medium'
        else:
            return 'low'


# Global instance
llm_service = LLMService()

