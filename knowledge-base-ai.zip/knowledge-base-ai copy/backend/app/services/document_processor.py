"""Document processing service - handles parsing of various document formats"""

import os
import logging
from typing import Dict, List, Tuple
from pathlib import Path
import PyPDF2
from docx import Document as DocxDocument

logger = logging.getLogger(__name__)


class DocumentProcessor:
    """Process various document formats and extract text"""
    
    SUPPORTED_FORMATS = {
        'pdf': 'application/pdf',
        'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'txt': 'text/plain',
        'md': 'text/markdown'
    }
    
    def __init__(self):
        self.processors = {
            'pdf': self._process_pdf,
            'docx': self._process_docx,
            'txt': self._process_txt,
            'md': self._process_txt,  # Markdown is processed like text
        }
    
    def get_file_extension(self, filename: str) -> str:
        """Get file extension from filename"""
        return Path(filename).suffix.lower().lstrip('.')
    
    def is_supported(self, filename: str) -> bool:
        """Check if file format is supported"""
        ext = self.get_file_extension(filename)
        return ext in self.SUPPORTED_FORMATS
    
    def process_document(self, file_path: str, filename: str) -> Tuple[str, Dict]:
        """
        Process a document and extract text
        
        Args:
            file_path: Path to the document file
            filename: Original filename
            
        Returns:
            Tuple of (extracted_text, metadata)
        """
        ext = self.get_file_extension(filename)
        
        if ext not in self.processors:
            raise ValueError(f"Unsupported file format: {ext}")
        
        try:
            text, metadata = self.processors[ext](file_path)
            metadata['filename'] = filename
            metadata['file_type'] = ext
            metadata['file_size'] = os.path.getsize(file_path)
            
            logger.info(f"Successfully processed {filename}: {len(text)} characters")
            return text, metadata
            
        except Exception as e:
            logger.error(f"Error processing {filename}: {str(e)}")
            raise
    
    def _process_pdf(self, file_path: str) -> Tuple[str, Dict]:
        """Process PDF file"""
        text_parts = []
        metadata = {'pages': []}
        
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            num_pages = len(pdf_reader.pages)
            
            for page_num in range(num_pages):
                page = pdf_reader.pages[page_num]
                page_text = page.extract_text()
                
                if page_text.strip():
                    text_parts.append(page_text)
                    metadata['pages'].append({
                        'page_number': page_num + 1,
                        'char_count': len(page_text)
                    })
            
            # Extract PDF metadata
            if pdf_reader.metadata:
                metadata['pdf_metadata'] = {
                    'title': pdf_reader.metadata.get('/Title', ''),
                    'author': pdf_reader.metadata.get('/Author', ''),
                    'subject': pdf_reader.metadata.get('/Subject', ''),
                }
        
        metadata['total_pages'] = num_pages
        full_text = '\n\n'.join(text_parts)
        
        return full_text, metadata
    
    def _process_docx(self, file_path: str) -> Tuple[str, Dict]:
        """Process DOCX file"""
        doc = DocxDocument(file_path)
        
        # Extract text from paragraphs
        paragraphs = [para.text for para in doc.paragraphs if para.text.strip()]
        full_text = '\n\n'.join(paragraphs)
        
        # Extract metadata
        metadata = {
            'total_paragraphs': len(doc.paragraphs),
            'total_tables': len(doc.tables),
        }
        
        # Extract core properties if available
        if doc.core_properties:
            metadata['docx_metadata'] = {
                'title': doc.core_properties.title or '',
                'author': doc.core_properties.author or '',
                'subject': doc.core_properties.subject or '',
                'created': str(doc.core_properties.created) if doc.core_properties.created else '',
            }
        
        return full_text, metadata
    
    def _process_txt(self, file_path: str) -> Tuple[str, Dict]:
        """Process TXT/MD file"""
        encodings_to_try = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
        
        for encoding in encodings_to_try:
            try:
                with open(file_path, 'r', encoding=encoding) as file:
                    text = file.read()
                
                # Count lines
                lines = text.split('\n')
                non_empty_lines = [line for line in lines if line.strip()]
                
                metadata = {
                    'total_lines': len(lines),
                    'non_empty_lines': len(non_empty_lines),
                    'encoding': encoding
                }
                
                return text, metadata
                
            except UnicodeDecodeError:
                continue
        
        raise ValueError(f"Could not decode text file with any supported encoding")
    
    def validate_document(self, file_path: str, max_size: int = 52428800) -> Tuple[bool, str]:
        """
        Validate document before processing
        
        Args:
            file_path: Path to the document
            max_size: Maximum file size in bytes (default 50MB)
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        # Check if file exists
        if not os.path.exists(file_path):
            return False, "File does not exist"
        
        # Check file size
        file_size = os.path.getsize(file_path)
        if file_size > max_size:
            return False, f"File size ({file_size} bytes) exceeds maximum ({max_size} bytes)"
        
        # Check if file is empty
        if file_size == 0:
            return False, "File is empty"
        
        return True, ""


# Global instance
document_processor = DocumentProcessor()

