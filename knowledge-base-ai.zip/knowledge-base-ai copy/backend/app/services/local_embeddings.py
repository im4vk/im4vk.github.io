"""Local embedding service using sentence-transformers (fallback for OpenAI)"""

import logging
from typing import List
import numpy as np

logger = logging.getLogger(__name__)

# Lazy loading to avoid import errors if not installed
_model = None


def get_local_model():
    """Lazy load the sentence transformer model"""
    global _model
    if _model is None:
        try:
            from sentence_transformers import SentenceTransformer
            logger.info("Loading local embedding model: all-MiniLM-L6-v2")
            _model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
            logger.info("✅ Local embedding model loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load local model: {e}")
            raise
    return _model


class LocalEmbeddingService:
    """Generate embeddings using local sentence-transformers model"""
    
    def __init__(self):
        self.model = None
        self.embedding_dim = 384  # Dimension for all-MiniLM-L6-v2
    
    def _ensure_model_loaded(self):
        """Ensure model is loaded"""
        if self.model is None:
            self.model = get_local_model()
    
    def generate_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for a single text
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
        """
        try:
            self._ensure_model_loaded()
            embedding = self.model.encode(text, convert_to_numpy=True)
            return embedding.tolist()
        except Exception as e:
            logger.error(f"Error generating local embedding: {str(e)}")
            raise
    
    def generate_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of embedding vectors
        """
        if not texts:
            return []
        
        try:
            self._ensure_model_loaded()
            logger.info(f"Generating local embeddings for {len(texts)} texts")
            embeddings = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
            return embeddings.tolist()
        except Exception as e:
            logger.error(f"Error generating batch embeddings: {str(e)}")
            raise
    
    def generate_query_embedding(self, query: str) -> List[float]:
        """Generate embedding for a search query"""
        return self.generate_embedding(query)


# Global instance
local_embedding_service = LocalEmbeddingService()

