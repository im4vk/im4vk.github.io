"""Enrichment service for knowledge base improvement"""

import logging
import wikipedia
from typing import List, Dict, Any
from app.config import settings

logger = logging.getLogger(__name__)


class EnrichmentService:
    """Analyze gaps and suggest/perform enrichment"""
    
    def __init__(self):
        # Configure Wikipedia
        wikipedia.set_lang("en")
        wikipedia.set_rate_limiting(True)
    
    def analyze_gaps(
        self,
        query: str,
        missing_info: List[str],
        confidence: float
    ) -> List[Dict[str, Any]]:
        """
        Analyze knowledge gaps and generate enrichment suggestions
        
        Args:
            query: Original query
            missing_info: List of missing information
            confidence: Confidence score of the answer
            
        Returns:
            List of enrichment suggestions
        """
        suggestions = []
        
        # Categorize gaps
        gap_categories = self._categorize_gaps(missing_info)
        
        # Generate suggestions based on confidence and gaps
        if confidence < 0.3:
            suggestions.append({
                'gap_type': 'critical',
                'description': 'Very limited information available to answer the query',
                'suggested_actions': [
                    f'Upload documents specifically about: {query}',
                    'Add comprehensive documentation or research papers',
                    'Include foundational materials on this topic'
                ],
                'priority': 'high'
            })
        
        # Suggestions based on gap categories
        if 'factual' in gap_categories:
            suggestions.append({
                'gap_type': 'factual',
                'description': 'Missing key facts and definitions',
                'suggested_actions': [
                    'Add reference materials or glossaries',
                    'Upload technical documentation',
                    f'Consider auto-enrichment from Wikipedia: {query}'
                ],
                'priority': 'high' if len(gap_categories['factual']) > 2 else 'medium'
            })
        
        if 'temporal' in gap_categories:
            suggestions.append({
                'gap_type': 'temporal',
                'description': 'Missing time-related information (dates, timelines, history)',
                'suggested_actions': [
                    'Add historical documentation',
                    'Include timeline or chronological data',
                    'Upload dated reports or news articles'
                ],
                'priority': 'medium'
            })
        
        if 'quantitative' in gap_categories:
            suggestions.append({
                'gap_type': 'quantitative',
                'description': 'Missing numerical data and statistics',
                'suggested_actions': [
                    'Add statistical reports or data sheets',
                    'Include quantitative research papers',
                    'Upload spreadsheets or data visualizations'
                ],
                'priority': 'high' if 'analysis' in query.lower() else 'medium'
            })
        
        if 'contextual' in gap_categories:
            suggestions.append({
                'gap_type': 'contextual',
                'description': 'Missing background context and explanations',
                'suggested_actions': [
                    'Add introductory or overview documents',
                    'Include explanatory articles or guides',
                    'Upload background research materials'
                ],
                'priority': 'medium'
            })
        
        # If no specific gaps but low confidence
        if not suggestions and confidence < 0.6:
            suggestions.append({
                'gap_type': 'general',
                'description': 'Knowledge base lacks depth on this topic',
                'suggested_actions': [
                    f'Add more documents related to: {query}',
                    'Increase coverage of related topics',
                    'Upload diverse sources for broader perspective'
                ],
                'priority': 'medium'
            })
        
        logger.info(f"Generated {len(suggestions)} enrichment suggestions")
        return suggestions
    
    def _categorize_gaps(self, missing_info: List[str]) -> Dict[str, List[str]]:
        """Categorize missing information into types"""
        categories = {
            'factual': [],
            'temporal': [],
            'contextual': [],
            'quantitative': []
        }
        
        for info in missing_info:
            info_lower = info.lower()
            
            if any(word in info_lower for word in ['when', 'date', 'time', 'year', 'period', 'timeline']):
                categories['temporal'].append(info)
            elif any(word in info_lower for word in ['how many', 'how much', 'number', 'amount', 'percentage', 'data']):
                categories['quantitative'].append(info)
            elif any(word in info_lower for word in ['what', 'who', 'which', 'definition', 'term']):
                categories['factual'].append(info)
            elif any(word in info_lower for word in ['why', 'how', 'context', 'background', 'reason', 'explanation']):
                categories['contextual'].append(info)
        
        # Remove empty categories
        return {k: v for k, v in categories.items() if v}
    
    async def auto_enrich_from_wikipedia(
        self,
        query: str,
        max_results: int = 3
    ) -> Dict[str, Any]:
        """
        Attempt to enrich knowledge base from Wikipedia
        
        Args:
            query: Topic to search for
            max_results: Maximum number of Wikipedia articles to fetch
            
        Returns:
            Enrichment result with fetched content
        """
        try:
            logger.info(f"Auto-enriching from Wikipedia: {query}")
            
            # Search Wikipedia
            search_results = wikipedia.search(query, results=max_results)
            
            if not search_results:
                return {
                    'success': False,
                    'message': 'No Wikipedia articles found for this query',
                    'sources': []
                }
            
            enriched_sources = []
            
            for title in search_results[:max_results]:
                try:
                    # Get article summary
                    page = wikipedia.page(title, auto_suggest=False)
                    
                    source = {
                        'title': page.title,
                        'url': page.url,
                        'summary': page.summary,
                        'content_preview': page.content[:1000] + "..." if len(page.content) > 1000 else page.content,
                        'source': 'wikipedia'
                    }
                    enriched_sources.append(source)
                    
                    logger.info(f"Fetched Wikipedia article: {page.title}")
                
                except wikipedia.exceptions.DisambiguationError as e:
                    logger.warning(f"Disambiguation error for {title}: {e}")
                    continue
                except wikipedia.exceptions.PageError:
                    logger.warning(f"Page not found: {title}")
                    continue
                except Exception as e:
                    logger.error(f"Error fetching Wikipedia page {title}: {str(e)}")
                    continue
            
            if enriched_sources:
                return {
                    'success': True,
                    'message': f'Successfully enriched with {len(enriched_sources)} Wikipedia articles',
                    'sources': enriched_sources
                }
            else:
                return {
                    'success': False,
                    'message': 'Could not fetch Wikipedia content',
                    'sources': []
                }
        
        except Exception as e:
            logger.error(f"Error during Wikipedia enrichment: {str(e)}")
            return {
                'success': False,
                'message': f'Enrichment failed: {str(e)}',
                'sources': []
            }
    
    def generate_enrichment_report(
        self,
        query: str,
        answer_confidence: float,
        missing_info: List[str],
        auto_enrichment_result: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Generate comprehensive enrichment report
        
        Args:
            query: Original query
            answer_confidence: Confidence of the answer
            missing_info: List of missing information
            auto_enrichment_result: Optional auto-enrichment results
            
        Returns:
            Comprehensive enrichment report
        """
        suggestions = self.analyze_gaps(query, missing_info, answer_confidence)
        
        report = {
            'query': query,
            'current_confidence': answer_confidence,
            'needs_enrichment': answer_confidence < settings.min_confidence_threshold or len(missing_info) > 0,
            'missing_information': missing_info,
            'suggestions': suggestions,
            'auto_enriched': auto_enrichment_result is not None and auto_enrichment_result.get('success', False),
            'new_sources': []
        }
        
        if auto_enrichment_result and auto_enrichment_result.get('success'):
            report['new_sources'] = [
                {
                    'title': source['title'],
                    'url': source['url'],
                    'source_type': 'wikipedia'
                }
                for source in auto_enrichment_result.get('sources', [])
            ]
        
        return report


# Global instance
enrichment_service = EnrichmentService()

