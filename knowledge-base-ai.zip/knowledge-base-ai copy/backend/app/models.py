"""Pydantic models for request/response schemas"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime


# Request Models
class SearchRequest(BaseModel):
    """Search request model"""
    query: str = Field(..., min_length=3, description="Search query")
    top_k: Optional[int] = Field(5, ge=1, le=20, description="Number of results to return")


class RatingRequest(BaseModel):
    """Rating request model"""
    query_id: int = Field(..., description="Query ID to rate")
    rating: int = Field(..., ge=-1, le=1, description="Rating: 1 (thumbs up) or -1 (thumbs down)")
    feedback: Optional[str] = Field(None, description="Optional feedback text")


class EnrichmentRequest(BaseModel):
    """Enrichment request model"""
    query: str = Field(..., description="Query that needs enrichment")
    missing_info: List[str] = Field(..., description="List of missing information")
    auto_enrich: bool = Field(False, description="Enable auto-enrichment from external sources")


# Response Models
class DocumentResponse(BaseModel):
    """Document response model"""
    id: int
    filename: str
    file_type: str
    file_size: int
    upload_date: datetime
    status: str
    num_chunks: int
    
    class Config:
        from_attributes = True


class SourceReference(BaseModel):
    """Source reference model"""
    document_id: int
    document_name: str
    page_number: Optional[int] = None
    chunk_text: str
    relevance_score: float


class SearchResponse(BaseModel):
    """Search response model"""
    query: str
    answer: str
    confidence: float = Field(..., ge=0.0, le=1.0, description="Confidence score (0-1)")
    sources: List[SourceReference]
    missing_info: List[str] = Field(default_factory=list, description="Missing information")
    enrichment_suggestions: List[str] = Field(default_factory=list, description="Enrichment suggestions")
    query_id: int
    response_time: float


class EnrichmentSuggestion(BaseModel):
    """Enrichment suggestion model"""
    gap_type: str = Field(..., description="Type of gap: temporal, factual, contextual")
    description: str = Field(..., description="Description of what's missing")
    suggested_actions: List[str] = Field(..., description="Actions to take")
    priority: str = Field(..., description="Priority: high, medium, low")


class EnrichmentResponse(BaseModel):
    """Enrichment response model"""
    query: str
    suggestions: List[EnrichmentSuggestion]
    auto_enriched: bool = Field(False, description="Whether auto-enrichment was performed")
    new_sources: List[str] = Field(default_factory=list, description="New sources added")


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    version: str
    timestamp: datetime
    database_connected: bool
    vector_store_connected: bool
    llm_connected: bool


class StatsResponse(BaseModel):
    """Statistics response"""
    total_documents: int
    total_chunks: int
    total_queries: int
    average_confidence: float
    average_response_time: float
    positive_ratings: int
    negative_ratings: int
    documents_by_type: Dict[str, int]


class UploadResponse(BaseModel):
    """Upload response model"""
    document_id: int
    filename: str
    file_size: int
    status: str
    num_chunks: int
    message: str


class ErrorResponse(BaseModel):
    """Error response model"""
    error: str
    detail: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)

