"""FastAPI main application"""

import os
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, File, UploadFile, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from datetime import datetime
import time

from app.config import settings
from app.database import init_db, get_db, Document as DBDocument
from app.models import (
    SearchRequest, SearchResponse, RatingRequest, EnrichmentRequest,
    EnrichmentResponse, HealthResponse, StatsResponse, UploadResponse,
    DocumentResponse, ErrorResponse
)
from app.services.document_processor import document_processor
from app.services.vector_store import vector_store
from app.services.rag_pipeline import rag_pipeline
from app.services.llm_service import llm_service
from app.services.enrichment_service import enrichment_service

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    # Startup
    logger.info("Starting up AI Knowledge Base...")
    init_db()
    
    # Create upload directory
    os.makedirs(settings.upload_directory, exist_ok=True)
    
    logger.info(f"Upload directory: {settings.upload_directory}")
    logger.info(f"Vector store: {settings.chroma_persist_directory}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down AI Knowledge Base...")


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="AI-Powered Knowledge Base with RAG Search & Enrichment",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """Global exception handler"""
    logger.error(f"Unhandled exception: {str(exc)}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=ErrorResponse(
            error="Internal server error",
            detail=str(exc) if settings.debug else "An unexpected error occurred"
        ).model_dump()
    )


@app.get("/", tags=["Root"])
async def root():
    """Root endpoint"""
    return {
        "name": settings.app_name,
        "version": settings.app_version,
        "status": "running",
        "docs": "/docs"
    }


@app.get("/api/v1/health", response_model=HealthResponse, tags=["System"])
async def health_check(db: Session = Depends(get_db)):
    """Health check endpoint"""
    
    # Check database connection
    db_connected = False
    try:
        db.execute("SELECT 1")
        db_connected = True
    except Exception as e:
        logger.error(f"Database health check failed: {str(e)}")
    
    # Check vector store
    vs_connected = False
    try:
        stats = vector_store.get_stats()
        vs_connected = "error" not in stats
    except Exception as e:
        logger.error(f"Vector store health check failed: {str(e)}")
    
    # Check LLM (basic check - would need actual API call for full check)
    llm_connected = bool(settings.openai_api_key and settings.openai_api_key != "your_openai_api_key_here")
    
    overall_status = "healthy" if (db_connected and vs_connected and llm_connected) else "degraded"
    
    return HealthResponse(
        status=overall_status,
        version=settings.app_version,
        timestamp=datetime.utcnow(),
        database_connected=db_connected,
        vector_store_connected=vs_connected,
        llm_connected=llm_connected
    )


@app.get("/api/v1/stats", response_model=StatsResponse, tags=["System"])
async def get_statistics(db: Session = Depends(get_db)):
    """Get knowledge base statistics"""
    from sqlalchemy import func
    from app.database import Query as DBQuery, Rating as DBRating
    
    try:
        # Document stats
        total_docs = db.query(DBDocument).count()
        
        # Chunk stats from vector store
        vs_stats = vector_store.get_stats()
        total_chunks = vs_stats.get("total_chunks", 0)
        
        # Query stats
        total_queries = db.query(DBQuery).count()
        avg_confidence = db.query(func.avg(DBQuery.confidence)).scalar() or 0.0
        avg_response_time = db.query(func.avg(DBQuery.response_time)).scalar() or 0.0
        
        # Rating stats
        positive_ratings = db.query(DBRating).filter(DBRating.rating == 1).count()
        negative_ratings = db.query(DBRating).filter(DBRating.rating == -1).count()
        
        # Documents by type
        docs_by_type = {}
        for doc in db.query(DBDocument.file_type, func.count(DBDocument.id)).group_by(DBDocument.file_type).all():
            docs_by_type[doc[0]] = doc[1]
        
        return StatsResponse(
            total_documents=total_docs,
            total_chunks=total_chunks,
            total_queries=total_queries,
            average_confidence=float(avg_confidence),
            average_response_time=float(avg_response_time),
            positive_ratings=positive_ratings,
            negative_ratings=negative_ratings,
            documents_by_type=docs_by_type
        )
    
    except Exception as e:
        logger.error(f"Error getting statistics: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve statistics: {str(e)}"
        )


@app.post("/api/v1/upload", response_model=UploadResponse, tags=["Documents"])
async def upload_document(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    Upload a document to the knowledge base
    
    Supports: PDF, DOCX, TXT, MD
    """
    start_time = time.time()
    
    # Validate file extension
    if not document_processor.is_supported(file.filename):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file format. Supported formats: {', '.join(settings.allowed_extensions)}"
        )
    
    # Save uploaded file
    file_path = os.path.join(settings.upload_directory, file.filename)
    
    try:
        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
        
        logger.info(f"File saved: {file_path}")
        
        # Validate document
        is_valid, error_msg = document_processor.validate_document(file_path, settings.max_upload_size)
        if not is_valid:
            os.remove(file_path)
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=error_msg)
        
        # Process document
        text, metadata = document_processor.process_document(file_path, file.filename)
        
        if not text.strip():
            os.remove(file_path)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Document contains no extractable text"
            )
        
        # Create database record
        db_document = DBDocument(
            filename=file.filename,
            file_type=metadata['file_type'],
            file_size=metadata['file_size'],
            status="processing"
        )
        db.add(db_document)
        db.commit()
        db.refresh(db_document)
        
        logger.info(f"Document record created: ID={db_document.id}")
        
        # Process document through RAG pipeline (chunking + embedding + storage)
        logger.info(f"Processing document through RAG pipeline...")
        result = await rag_pipeline.process_document(
            document_id=db_document.id,
            file_path=file_path,
            filename=file.filename,
            db=db
        )
        
        processing_time = time.time() - start_time
        logger.info(f"Document processed successfully in {processing_time:.2f}s")
        
        return UploadResponse(
            document_id=db_document.id,
            filename=file.filename,
            file_size=metadata['file_size'],
            status=result['status'],
            num_chunks=result['num_chunks'],
            message=f"Document processed successfully. Created {result['num_chunks']} chunks from {result['total_tokens']} tokens."
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error uploading document: {str(e)}", exc_info=True)
        
        # Clean up file if exists
        if os.path.exists(file_path):
            os.remove(file_path)
        
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to upload document: {str(e)}"
        )


@app.get("/api/v1/documents", response_model=list[DocumentResponse], tags=["Documents"])
async def list_documents(db: Session = Depends(get_db)):
    """List all uploaded documents"""
    documents = db.query(DBDocument).order_by(DBDocument.upload_date.desc()).all()
    return documents


@app.delete("/api/v1/documents/{document_id}", tags=["Documents"])
async def delete_document(document_id: int, db: Session = Depends(get_db)):
    """Delete a document and its chunks"""
    document = db.query(DBDocument).filter(DBDocument.id == document_id).first()
    
    if not document:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document {document_id} not found"
        )
    
    try:
        # Delete from vector store
        vector_store.delete_by_document_id(document_id)
        
        # Delete file
        file_path = os.path.join(settings.upload_directory, document.filename)
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # Delete from database (cascades to chunks and queries)
        db.delete(document)
        db.commit()
        
        logger.info(f"Document {document_id} deleted successfully")
        
        return {"message": f"Document {document_id} deleted successfully"}
    
    except Exception as e:
        logger.error(f"Error deleting document: {str(e)}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete document: {str(e)}"
        )


@app.post("/api/v1/search", response_model=SearchResponse, tags=["Search"])
async def search(request: SearchRequest, db: Session = Depends(get_db)):
    """
    Search knowledge base with AI-powered answer generation
    
    Returns structured response with:
    - AI-generated answer
    - Confidence score
    - Source references
    - Missing information
    - Enrichment suggestions
    """
    from app.database import Query as DBQuery
    import time
    
    start_time = time.time()
    
    try:
        # Step 1: Retrieve relevant chunks
        logger.info(f"Searching for: {request.query}")
        retrieved_chunks = rag_pipeline.search(
            query=request.query,
            top_k=request.top_k
        )
        
        if not retrieved_chunks:
            # No relevant chunks found
            query_record = DBQuery(
                query_text=request.query,
                answer="No relevant information found in the knowledge base.",
                confidence=0.0,
                response_time=time.time() - start_time
            )
            db.add(query_record)
            db.commit()
            db.refresh(query_record)
            
            return SearchResponse(
                query=request.query,
                answer="No relevant information found in the knowledge base.",
                confidence=0.0,
                sources=[],
                missing_info=["No documents available to answer this question"],
                enrichment_suggestions=["Upload documents related to: " + request.query],
                query_id=query_record.id,
                response_time=time.time() - start_time
            )
        
        # Step 2: Generate answer with LLM
        logger.info(f"Generating answer from {len(retrieved_chunks)} chunks...")
        llm_result = llm_service.generate_answer(
            query=request.query,
            retrieved_chunks=retrieved_chunks
        )
        
        # Step 3: Format sources
        sources = []
        for chunk in retrieved_chunks:
            metadata = chunk.get('metadata', {})
            source_ref = {
                'document_id': metadata.get('document_id', 0),
                'document_name': metadata.get('filename', 'Unknown'),
                'page_number': metadata.get('page_number'),
                'chunk_text': chunk['chunk_text'][:200] + "..." if len(chunk['chunk_text']) > 200 else chunk['chunk_text'],
                'relevance_score': 1.0 - chunk.get('distance', 0.0) if chunk.get('distance') is not None else 0.0
            }
            sources.append(source_ref)
        
        # Step 4: Store query in database
        response_time = time.time() - start_time
        query_record = DBQuery(
            query_text=request.query,
            answer=llm_result['answer'],
            confidence=llm_result['confidence'],
            response_time=response_time
        )
        db.add(query_record)
        db.commit()
        db.refresh(query_record)
        
        logger.info(f"Search completed in {response_time:.2f}s with confidence {llm_result['confidence']:.2f}")
        
        return SearchResponse(
            query=request.query,
            answer=llm_result['answer'],
            confidence=llm_result['confidence'],
            sources=sources,
            missing_info=llm_result.get('missing_info', []),
            enrichment_suggestions=llm_result.get('enrichment_suggestions', []),
            query_id=query_record.id,
            response_time=response_time
        )
    
    except Exception as e:
        logger.error(f"Error during search: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Search failed: {str(e)}"
        )


@app.post("/api/v1/rate-answer", tags=["Feedback"])
async def rate_answer(request: RatingRequest, db: Session = Depends(get_db)):
    """
    Rate an answer (thumbs up/down) with optional feedback
    
    Helps improve the system over time by tracking answer quality
    """
    from app.database import Rating as DBRating, Query as DBQuery
    
    try:
        # Check if query exists
        query = db.query(DBQuery).filter(DBQuery.id == request.query_id).first()
        if not query:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Query {request.query_id} not found"
            )
        
        # Create rating
        rating = DBRating(
            query_id=request.query_id,
            rating=request.rating,
            feedback=request.feedback
        )
        db.add(rating)
        db.commit()
        db.refresh(rating)
        
        logger.info(f"Rating recorded for query {request.query_id}: {request.rating}")
        
        return {
            "message": "Rating recorded successfully",
            "rating_id": rating.id,
            "query_id": request.query_id
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error recording rating: {str(e)}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to record rating: {str(e)}"
        )


@app.post("/api/v1/enrich", response_model=EnrichmentResponse, tags=["Enrichment"])
async def enrich_knowledge_base(request: EnrichmentRequest, db: Session = Depends(get_db)):
    """
    Analyze knowledge gaps and suggest enrichment strategies
    
    Optionally performs auto-enrichment from Wikipedia
    """
    from app.database import EnrichmentLog as DBEnrichmentLog
    
    try:
        logger.info(f"Enrichment requested for: {request.query}")
        
        # Analyze gaps and generate suggestions
        suggestions = enrichment_service.analyze_gaps(
            query=request.query,
            missing_info=request.missing_info,
            confidence=0.5  # Default confidence if not provided
        )
        
        # Convert to EnrichmentSuggestion models
        from app.models import EnrichmentSuggestion
        enrichment_suggestions = [
            EnrichmentSuggestion(
                gap_type=s['gap_type'],
                description=s['description'],
                suggested_actions=s['suggested_actions'],
                priority=s['priority']
            )
            for s in suggestions
        ]
        
        # Auto-enrich if requested
        auto_enriched = False
        new_sources = []
        
        if request.auto_enrich:
            logger.info("Performing auto-enrichment from Wikipedia...")
            wiki_result = await enrichment_service.auto_enrich_from_wikipedia(
                query=request.query,
                max_results=3
            )
            
            if wiki_result['success']:
                auto_enriched = True
                new_sources = [
                    f"{source['title']} ({source['url']})"
                    for source in wiki_result['sources']
                ]
                
                # Log enrichment
                for source in wiki_result['sources']:
                    enrichment_log = DBEnrichmentLog(
                        gap_type='auto_wikipedia',
                        suggestion=f"Added Wikipedia article: {source['title']}",
                        status='completed',
                        source='wikipedia'
                    )
                    db.add(enrichment_log)
                
                db.commit()
                logger.info(f"Auto-enriched with {len(new_sources)} Wikipedia sources")
        
        # Log enrichment suggestions
        for suggestion in suggestions:
            enrichment_log = DBEnrichmentLog(
                gap_type=suggestion['gap_type'],
                suggestion=suggestion['description'],
                status='pending',
                source='manual'
            )
            db.add(enrichment_log)
        
        db.commit()
        
        return EnrichmentResponse(
            query=request.query,
            suggestions=enrichment_suggestions,
            auto_enriched=auto_enriched,
            new_sources=new_sources
        )
    
    except Exception as e:
        logger.error(f"Error during enrichment: {str(e)}", exc_info=True)
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Enrichment failed: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=settings.host, port=settings.port, reload=settings.debug)

