"""Application configuration"""

from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    """Application settings"""
    
    # Application
    app_name: str = "AI Knowledge Base"
    app_version: str = "1.0.0"
    debug: bool = True
    log_level: str = "INFO"
    
    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    
    # OpenAI
    openai_api_key: str = "demo-mode"  # Default for demo
    embedding_model: str = "text-embedding-3-small"
    llm_model: str = "gpt-4-turbo-preview"
    max_tokens: int = 4096
    temperature: float = 0.7
    
    # Local Models (Fallback)
    use_local_models: bool = False  # Auto-enabled if OpenAI fails
    local_embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    
    # Database
    database_url: str = "sqlite:///./kb_metadata.db"
    chroma_persist_directory: str = "./chroma_db"
    
    # File Upload
    max_upload_size: int = 52428800  # 50MB
    allowed_extensions: str = "pdf,docx,txt,md"
    upload_directory: str = "./uploads"
    
    @property
    def allowed_extensions_list(self) -> List[str]:
        """Get allowed extensions as list"""
        return [ext.strip() for ext in self.allowed_extensions.split(',')]
    
    # RAG Configuration
    chunk_size: int = 512
    chunk_overlap: int = 200
    top_k_retrieval: int = 5
    min_confidence_threshold: float = 0.5
    
    # Rate Limiting
    rate_limit_per_minute: int = 60
    
    # CORS
    cors_origins: str = "http://localhost:5173,http://localhost:3000"
    
    @property
    def cors_origins_list(self) -> List[str]:
        """Get CORS origins as list"""
        return [origin.strip() for origin in self.cors_origins.split(',')]
    
    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()

