"""AI-Powered Knowledge Base Backend"""

__version__ = "1.0.0"

